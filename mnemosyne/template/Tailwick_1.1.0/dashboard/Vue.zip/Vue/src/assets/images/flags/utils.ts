import usFlag from "@/assets/images/flags/20/us.svg";
import esFlag from "@/assets/images/flags/20/es.svg";
import deFlag from "@/assets/images/flags/20/de.svg";
import frFlag from "@/assets/images/flags/20/fr.svg";
import jpFlag from "@/assets/images/flags/20/jp.svg";
import chinaFlag from "@/assets/images/flags/20/china.svg";
import itFlag from "@/assets/images/flags/20/it.svg";
import ruFlag from "@/assets/images/flags/20/ru.svg";
import aeFlag from "@/assets/images/flags/20/ae.svg";

export {
  usFlag,
  esFlag,
  deFlag,
  frFlag,
  jpFlag,
  chinaFlag,
  itFlag,
  ruFlag,
  aeFlag
};
