import bg from "@/assets/images/product/bg.png";
import cta2 from "@/assets/images/product/cta-2.png";
import cta from "@/assets/images/product/cta.png";
import img01 from "@/assets/images/product/img-01.png";
import img02 from "@/assets/images/product/img-02.png";
import img03 from "@/assets/images/product/img-03.png";
import img04 from "@/assets/images/product/img-04.png";
import img05 from "@/assets/images/product/img-05.png";
import img06 from "@/assets/images/product/img-06.png";
import img07 from "@/assets/images/product/img-07.png";
import img08 from "@/assets/images/product/img-08.png";
import img09 from "@/assets/images/product/img-09.png";
import img10 from "@/assets/images/product/img-10.png";
import img11 from "@/assets/images/product/img-11.png";
import img12 from "@/assets/images/product/img-12.png";
import img13 from "@/assets/images/product/img-13.png";
import img14 from "@/assets/images/product/img-14.png";
import img15 from "@/assets/images/product/img-15.png";
import img16 from "@/assets/images/product/img-16.png";
import img17 from "@/assets/images/product/img-17.png";
import img18 from "@/assets/images/product/img-18.png";
import img19 from "@/assets/images/product/img-19.png";
import overview01 from "@/assets/images/product/overview-01.png";
import overview02 from "@/assets/images/product/overview-02.png";

export {
  bg,
  cta2,
  cta,
  img01,
  img02,
  img03,
  img04,
  img05,
  img06,
  img07,
  img08,
  img09,
  img10,
  img11,
  img12,
  img13,
  img14,
  img15,
  img16,
  img17,
  img18,
  img19,
  overview01,
  overview02
};
