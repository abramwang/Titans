import ar from "@/assets/lang/ar.json";
import ch from "@/assets/lang/ch.json";
import en from "@/assets/lang/en.json";
import fr from "@/assets/lang/fr.json";
import gr from "@/assets/lang/gr.json";
import it from "@/assets/lang/it.json";
import jp from "@/assets/lang/jp.json";
import ru from "@/assets/lang/ru.json";
import sp from "@/assets/lang/sp.json";

export default { ar, ch, en, fr, gr, it, jp, ru, sp };
