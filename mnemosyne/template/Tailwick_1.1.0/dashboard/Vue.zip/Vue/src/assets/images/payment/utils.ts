import img1 from "@/assets/images/payment/img-01.png";
import img2 from "@/assets/images/payment/img-02.png";
import img3 from "@/assets/images/payment/img-03.png";
import img4 from "@/assets/images/payment/img-04.png";

export { img1, img2, img3, img4 };
