import comingSoon from "@/assets/images/auth/coming-soon.png";
import error404 from "@/assets/images/auth/error-404.png";
import img1 from "@/assets/images/auth/img-01.png";
import maintenance from "@/assets/images/auth/maintenance.png";
import offline from "@/assets/images/auth/offline.png";

export { comingSoon, error404, img1, maintenance, offline };
