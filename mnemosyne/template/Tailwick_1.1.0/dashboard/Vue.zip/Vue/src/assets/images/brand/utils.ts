import adwords from "@/assets/images/brand/adwords.png";
import android from "@/assets/images/brand/android.png";
import appStore from "@/assets/images/brand/app-store.png";
import delivery1 from "@/assets/images/brand/delivery-1.png";
import delivery2 from "@/assets/images/brand/delivery-2.png";
import delivery3 from "@/assets/images/brand/delivery-3.png";
import figma from "@/assets/images/brand/figma.png";
import gmail from "@/assets/images/brand/gmail.png";
import meta from "@/assets/images/brand/meta.png";
import search from "@/assets/images/brand/search.png";
import slack from "@/assets/images/brand/slack.png";
import telegram from "@/assets/images/brand/telegram.png";
import twitter from "@/assets/images/brand/twitter.png";

export {
  adwords,
  android,
  appStore,
  delivery1,
  delivery2,
  delivery3,
  figma,
  gmail,
  meta,
  search,
  slack,
  telegram,
  twitter
};
