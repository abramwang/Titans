<script lang="ts" setup>
import Dashboard from "@/components/eCommerce/orders/Dashboard.vue";
import ListingTable from "@/components/eCommerce/orders/ListingTable.vue";
</script>
<template>
  <Dashboard />
  <ListingTable />
</template>
