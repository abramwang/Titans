export interface Employee {
    id: number;
    employeeId: string;
    name: string;
    img: string;
    designation: string;
    email: string;
    phone: string;
    location: string;
    experience: string;
    joinDate: string;
}
