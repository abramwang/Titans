<script lang="ts" setup></script>
<template>
  <TCard title="Icon With Switch">
    <div class="flex flex-col gap-3">
      <div class="flex items-center">
        <div
          class="relative inline-block w-10 align-middle transition duration-200 ease-in ltr:mr-2 rtl:ml-2"
        >
          <input
            type="checkbox"
            name="customIconSwitch"
            id="customIconSwitch"
            class="absolute block size-5 transition duration-300 ease-linear border-2 border-slate-200 dark:border-zink-500 rounded-full appearance-none cursor-pointer bg-white/80 dark:bg-zink-600 peer/published checked:bg-white dark:checked:bg-white ltr:checked:right-0 rtl:checked:left-0 checked:bg-none checked:border-custom-500 dark:checked:border-custom-500 arrow-none after:absolute after:text-slate-500 dark:after:text-zink-200 after:content-['\eb99'] after:text-xs after:inset-0 after:flex after:items-center after:justify-center after:font-remix after:leading-none checked:after:text-custom-500 dark:checked:after:text-custom-500 checked:after:content-['\eb7b']"
            checked
          />
          <label
            for="customIconSwitch"
            class="block h-5 overflow-hidden duration-300 ease-linear border rounded-full cursor-pointer cursor-pointertransition border-slate-200 dark:border-zink-500 bg-slate-200 dark:bg-zink-600 peer-checked/published:bg-custom-500 peer-checked/published:border-custom-500"
          />
        </div>
        <label
          for="customIconSwitch"
          class="inline-block text-base font-medium cursor-pointer"
          >Custom Switch</label
        >
      </div>
      <div class="flex items-center">
        <div
          class="relative inline-block w-10 align-middle transition duration-200 ease-in ltr:mr-2 rtl:ml-2"
        >
          <input
            type="checkbox"
            name="greenIconSwitch"
            id="greenIconSwitch"
            class="absolute block size-5 transition duration-300 ease-linear border-2 border-slate-200 dark:border-zink-500 rounded-full appearance-none cursor-pointer bg-white/80 dark:bg-zink-600 peer/published checked:bg-white dark:checked:bg-white ltr:checked:right-0 rtl:checked:left-0 checked:bg-none checked:border-green-500 dark:checked:border-green-500 arrow-none after:absolute after:text-slate-500 dark:after:text-zink-200 after:content-['\eb99'] after:text-xs after:inset-0 after:flex after:items-center after:justify-center after:font-remix after:leading-none checked:after:text-green-500 dark:checked:after:text-green-500 checked:after:content-['\eb7b']"
            checked
          />
          <label
            for="greenIconSwitch"
            class="block h-5 overflow-hidden duration-300 ease-linear border rounded-full cursor-pointer cursor-pointertransition border-slate-200 dark:border-zink-500 bg-slate-200 dark:bg-zink-600 peer-checked/published:bg-green-500 peer-checked/published:border-green-500"
          />
        </div>
        <label
          for="greenIconSwitch"
          class="inline-block text-base font-medium cursor-pointer"
          >Green Switch</label
        >
      </div>
      <div class="flex items-center">
        <div
          class="relative inline-block w-10 align-middle transition duration-200 ease-in ltr:mr-2 rtl:ml-2"
        >
          <input
            type="checkbox"
            name="orangeIconSwitch"
            id="orangeIconSwitch"
            class="absolute block size-5 transition duration-300 ease-linear border-2 border-slate-200 dark:border-zink-500 rounded-full appearance-none cursor-pointer bg-white/80 dark:bg-zink-600 peer/published checked:bg-white dark:checked:bg-white ltr:checked:right-0 rtl:checked:left-0 checked:bg-none checked:border-orange-500 dark:checked:border-orange-500 arrow-none after:absolute after:text-slate-500 dark:after:text-zink-200 after:content-['\eb99'] after:text-xs after:inset-0 after:flex after:items-center after:justify-center after:font-remix after:leading-none checked:after:text-orange-500 dark:checked:after:text-orange-500 checked:after:content-['\eb7b']"
            checked
          />
          <label
            for="orangeIconSwitch"
            class="block h-5 overflow-hidden duration-300 ease-linear border rounded-full cursor-pointer cursor-pointertransition border-slate-200 dark:border-zink-500 bg-slate-200 dark:bg-zink-600 peer-checked/published:bg-orange-500 peer-checked/published:border-orange-500"
          />
        </div>
        <label
          for="orangeIconSwitch"
          class="inline-block text-base font-medium cursor-pointer"
          >Orange Switch</label
        >
      </div>
      <div class="flex items-center">
        <div
          class="relative inline-block w-10 align-middle transition duration-200 ease-in ltr:mr-2 rtl:ml-2"
        >
          <input
            type="checkbox"
            name="skyIconSwitch"
            id="skyIconSwitch"
            class="absolute block size-5 transition duration-300 ease-linear border-2 border-slate-200 dark:border-zink-500 rounded-full appearance-none cursor-pointer bg-white/80 dark:bg-zink-600 peer/published checked:bg-white dark:checked:bg-white ltr:checked:right-0 rtl:checked:left-0 checked:bg-none checked:border-sky-500 dark:checked:border-sky-500 arrow-none after:absolute after:text-slate-500 dark:after:text-zink-200 after:content-['\eb99'] after:text-xs after:inset-0 after:flex after:items-center after:justify-center after:font-remix after:leading-none checked:after:text-sky-500 dark:checked:after:text-sky-500 checked:after:content-['\eb7b']"
            checked
          />
          <label
            for="skyIconSwitch"
            class="block h-5 overflow-hidden duration-300 ease-linear border rounded-full cursor-pointer cursor-pointertransition border-slate-200 dark:border-zink-500 bg-slate-200 dark:bg-zink-600 peer-checked/published:bg-sky-500 peer-checked/published:border-sky-500"
          />
        </div>
        <label
          for="skyIconSwitch"
          class="inline-block text-base font-medium cursor-pointer"
          >Sky Switch</label
        >
      </div>
      <div class="flex items-center">
        <div
          class="relative inline-block w-10 align-middle transition duration-200 ease-in ltr:mr-2 rtl:ml-2"
        >
          <input
            type="checkbox"
            name="yellowIconSwitch"
            id="yellowIconSwitch"
            class="absolute block size-5 transition duration-300 ease-linear border-2 border-slate-200 dark:border-zink-500 rounded-full appearance-none cursor-pointer bg-white/80 dark:bg-zink-600 peer/published checked:bg-white dark:checked:bg-white ltr:checked:right-0 rtl:checked:left-0 checked:bg-none checked:border-yellow-500 dark:checked:border-yellow-500 arrow-none after:absolute after:text-slate-500 dark:after:text-zink-200 after:content-['\eb99'] after:text-xs after:inset-0 after:flex after:items-center after:justify-center after:font-remix after:leading-none checked:after:text-yellow-500 dark:checked:after:text-yellow-500 checked:after:content-['\eb7b']"
            checked
          />
          <label
            for="yellowIconSwitch"
            class="block h-5 overflow-hidden duration-300 ease-linear border rounded-full cursor-pointer cursor-pointertransition border-slate-200 dark:border-zink-500 bg-slate-200 dark:bg-zink-600 peer-checked/published:bg-yellow-500 peer-checked/published:border-yellow-500"
          />
        </div>
        <label
          for="yellowIconSwitch"
          class="inline-block text-base font-medium cursor-pointer"
          >Yellow Switch</label
        >
      </div>
      <div class="flex items-center">
        <div
          class="relative inline-block w-10 align-middle transition duration-200 ease-in ltr:mr-2 rtl:ml-2"
        >
          <input
            type="checkbox"
            name="redIconSwitch"
            id="redIconSwitch"
            class="absolute block size-5 transition duration-300 ease-linear border-2 border-slate-200 dark:border-zink-500 rounded-full appearance-none cursor-pointer bg-white/80 dark:bg-zink-600 peer/published checked:bg-white dark:checked:bg-white ltr:checked:right-0 rtl:checked:left-0 checked:bg-none checked:border-red-500 dark:checked:border-red-500 arrow-none after:absolute after:text-slate-500 dark:after:text-zink-200 after:content-['\eb99'] after:text-xs after:inset-0 after:flex after:items-center after:justify-center after:font-remix after:leading-none checked:after:text-red-500 dark:checked:after:text-red-500 checked:after:content-['\eb7b']"
            checked
          />
          <label
            for="redIconSwitch"
            class="block h-5 overflow-hidden duration-300 ease-linear border rounded-full cursor-pointer cursor-pointertransition border-slate-200 dark:border-zink-500 bg-slate-200 dark:bg-zink-600 peer-checked/published:bg-red-500 peer-checked/published:border-red-500"
          />
        </div>
        <label
          for="redIconSwitch"
          class="inline-block text-base font-medium cursor-pointer"
          >Red Switch</label
        >
      </div>
      <div class="flex items-center">
        <div
          class="relative inline-block w-10 align-middle transition duration-200 ease-in ltr:mr-2 rtl:ml-2"
        >
          <input
            type="checkbox"
            name="purpleIconSwitch"
            id="purpleIconSwitch"
            class="absolute block size-5 transition duration-300 ease-linear border-2 border-slate-200 dark:border-zink-500 rounded-full appearance-none cursor-pointer bg-white/80 dark:bg-zink-600 peer/published checked:bg-white dark:checked:bg-white ltr:checked:right-0 rtl:checked:left-0 checked:bg-none checked:border-purple-500 dark:checked:border-purple-500 arrow-none after:absolute after:text-slate-500 dark:after:text-zink-200 after:content-['\eb99'] after:text-xs after:inset-0 after:flex after:items-center after:justify-center after:font-remix after:leading-none checked:after:text-purple-500 dark:checked:after:text-purple-500 checked:after:content-['\eb7b']"
            checked
          />
          <label
            for="purpleIconSwitch"
            class="block h-5 overflow-hidden duration-300 ease-linear border rounded-full cursor-pointer cursor-pointertransition border-slate-200 dark:border-zink-500 bg-slate-200 dark:bg-zink-600 peer-checked/published:bg-purple-500 peer-checked/published:border-purple-500"
          />
        </div>
        <label
          for="purpleIconSwitch"
          class="inline-block text-base font-medium cursor-pointer"
          >Purple Switch</label
        >
      </div>
      <div class="flex items-center">
        <div
          class="relative inline-block w-10 align-middle transition duration-200 ease-in ltr:mr-2 rtl:ml-2"
        >
          <input
            type="checkbox"
            name="lightIconSwitch"
            id="lightIconSwitch"
            class="absolute block size-5 transition duration-300 ease-linear border-2 border-slate-200 dark:border-zink-500 rounded-full appearance-none cursor-pointer bg-white/80 dark:bg-zink-600 peer/published checked:bg-white dark:checked:bg-white ltr:checked:right-0 rtl:checked:left-0 checked:bg-none checked:border-slate-400 dark:checked:border-slate-400 arrow-none after:absolute after:text-slate-500 dark:after:text-zink-200 after:content-['\eb99'] after:text-xs after:inset-0 after:flex after:items-center after:justify-center after:font-remix after:leading-none checked:after:text-slate-400 dark:checked:after:text-slate-400 checked:after:content-['\eb7b']"
            checked
          />
          <label
            for="lightIconSwitch"
            class="block h-5 overflow-hidden duration-300 ease-linear border rounded-full cursor-pointer cursor-pointertransition border-slate-200 dark:border-zink-500 bg-slate-200 dark:bg-zink-600 peer-checked/published:bg-slate-400 peer-checked/published:border-slate-400"
          />
        </div>
        <label
          for="lightIconSwitch"
          class="inline-block text-base font-medium cursor-pointer"
          >Light Switch</label
        >
      </div>
      <div class="flex items-center">
        <div
          class="relative inline-block w-10 align-middle transition duration-200 ease-in ltr:mr-2 rtl:ml-2"
        >
          <input
            type="checkbox"
            name="darkIconSwitch"
            id="darkIconSwitch"
            class="absolute block size-5 transition duration-300 ease-linear border-2 border-slate-200 dark:border-zink-500 rounded-full appearance-none cursor-pointer bg-white/80 dark:bg-zink-600 peer/published checked:bg-white dark:checked:bg-white ltr:checked:right-0 rtl:checked:left-0 checked:bg-none checked:border-slate-700 dark:checked:border-slate-700 arrow-none after:absolute after:text-slate-500 dark:after:text-zink-200 after:content-['\eb99'] after:text-xs after:inset-0 after:flex after:items-center after:justify-center after:font-remix after:leading-none checked:after:text-slate-700 dark:checked:after:text-slate-700 checked:after:content-['\eb7b']"
            checked
          />
          <label
            for="darkIconSwitch"
            class="block h-5 overflow-hidden duration-300 ease-linear border rounded-full cursor-pointer cursor-pointertransition border-slate-200 dark:border-zink-500 bg-slate-200 dark:bg-zink-600 peer-checked/published:bg-slate-700 peer-checked/published:border-slate-700"
          />
        </div>
        <label
          for="darkIconSwitch"
          class="inline-block text-base font-medium cursor-pointer"
        >
          Dark Switch
        </label>
      </div>
    </div>
  </TCard>
</template>
