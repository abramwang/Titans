<script lang="ts" setup></script>
<template>
  <div class="h-full p-4 overflow-y-auto">
    <div class="card-body">
      <h6 class="mb-4 text-15">Drawer Content</h6>
      <p class="text-slate-500 dark:text-zink-200">
        They all have something to say beyond the words on the page. They can
        come across as casual or neutral, exotic or graphic.
      </p>
    </div>
  </div>
  <div
    class="flex items-center justify-between p-4 border-t border-slate-200 dark:border-zink-500"
  >
    <h6 class="text-15">Drawer Footer</h6>
  </div>
</template>
