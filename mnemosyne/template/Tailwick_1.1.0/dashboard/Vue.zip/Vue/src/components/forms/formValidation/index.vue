<script lang="ts" setup>
import BrowserDefault from "@/components/forms/formValidation/BrowserDefault.vue";
import SignUpForm from "@/components/forms/formValidation/SignUpForm.vue";
</script>
<template>
  <BrowserDefault />
  <SignUpForm />
</template>