import {
  img01,
  img02,
  img03,
  img04,
  img05,
  img06,
  img07,
  img08,
} from "@/assets/images/product/utils";

export const marketplaceData = [
  {
    imageUrl: img05,
  },
  {
    imageUrl: img02,
  },
  {
    imageUrl: img03,
  },
  {
    imageUrl: img04,
  },
  {
    imageUrl: img01,
  },
  {
    imageUrl: img06,
  },
  {
    imageUrl: img07,
  },
  {
    imageUrl: img08,
  },
];
