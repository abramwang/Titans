<template>
  <div class="grid grid-cols-1 gap-x-5 xl:grid-cols-2">
    <TCard title="Preview Video Player">
      <div class="plyr__video-embed" id="player">
        <iframe
          src="https://www.youtube.com/embed/qYgogv4R8zg?si=_YxUDmc2fDgHyPae"
          allowfullscreen
          allowtransparency
          allow="autoplay"
          height="430"
          width="100%"
        ></iframe>
      </div>
    </TCard>
  </div>
</template>
