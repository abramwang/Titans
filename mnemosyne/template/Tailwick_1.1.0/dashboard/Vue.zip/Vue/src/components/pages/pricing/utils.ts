export const horizontalData = [
  {
    plan: "Personal Plan",
  },
  {
    plan: "Enterprise Plan",
  },
];

export const lists = [
  {
    items: [
      { icon: "CheckSquare", text: "3 Projects", bold: true },
      { icon: "CheckSquare", text: "299 Customers", bold: true },
    ],
  },
  {
    items: [
      { icon: "CheckSquare", text: "3 Projects", bold: true },
      { icon: "CheckSquare", text: "299 Customers", bold: true },
      { icon: "CheckSquare", text: "Scalable Bandwidth" },
      { icon: "CheckSquare", text: "5 No Team Account", bold: true },
    ],
  },
];
