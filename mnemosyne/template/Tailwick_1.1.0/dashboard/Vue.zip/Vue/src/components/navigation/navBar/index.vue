<script lang="ts" setup>
import Basic from "@/components/navigation/navBar/Basic.vue";
import HamburgerMenu from "@/components/navigation/navBar/HamburgerMenu.vue";
import NavWithButton from "@/components/navigation/navBar/NavWithButton.vue";
import NavWithSearch from "@/components/navigation/navBar/NavWithSearch.vue";
import DarkNav from "@/components/navigation/navBar/DarkNav.vue";
</script>
<template>
  <Basic />
  <HamburgerMenu />
  <NavWithButton />
  <NavWithSearch />
  <DarkNav />
</template>
