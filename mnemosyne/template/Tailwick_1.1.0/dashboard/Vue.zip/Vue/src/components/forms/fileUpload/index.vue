<script lang="ts" setup></script>
<template>
  <TCard title="Dropzone">
    <TFileUploader />
  </TCard>
  <TCard title="Bordered Dashed Dropzone">
    <TFileUploader dashed />
  </TCard>
  <TCard title="Upload Multiple files">
    <TFileUploader multiple dashed />
  </TCard>
</template>
