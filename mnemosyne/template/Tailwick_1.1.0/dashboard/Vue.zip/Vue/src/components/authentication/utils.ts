import { Facebook, Mail, Twitter, Github } from "lucide-vue-next";

export const socialMedias = [
  { icon: Facebook, color: "custom" },
  { icon: Mail, color: "orange" },
  { icon: Twitter, color: "sky" },
  { icon: Github, color: "slate" }
];
