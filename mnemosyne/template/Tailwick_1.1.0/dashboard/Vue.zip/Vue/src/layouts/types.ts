export const LAYOUT_TYPES = {
  BASIC: "basic",
  COVER: "cover",
  BOXED: "boxed",
  MODERN: "modern"
};
