export type TableHeaderType = {
  title?: string;
  type?: string;
  value: string;
  align?: string;
  justifyCenter?: boolean;
};
