<template>
  <label
    class="block w-full h-24 p-0 overflow-hidden border rounded-lg cursor-pointer border-slate-200 dark:border-zink-500"
  >
    <span class="flex h-full gap-0">
      <span class="shrink-0">
        <span
          class="flex flex-col h-full gap-1 p-1 ltr:border-r rtl:border-l border-slate-200 dark:border-zink-500"
        >
          <span
            class="block p-1 px-2 mb-2 rounded bg-slate-100 dark:bg-zink-400"
          ></span>
          <span
            class="block p-1 px-2 pb-0 bg-slate-100 dark:bg-zink-500"
          ></span>
          <span
            class="block p-1 px-2 pb-0 bg-slate-100 dark:bg-zink-500"
          ></span>
          <span
            class="block p-1 px-2 pb-0 bg-slate-100 dark:bg-zink-500"
          ></span>
        </span>
      </span>
      <span class="grow">
        <span class="flex flex-col h-full">
          <span class="block h-3 bg-slate-100 dark:bg-zink-500"></span>
          <span class="block h-3 mt-auto bg-slate-100 dark:bg-zink-500"></span>
        </span>
      </span>
    </span>
  </label>
</template>
