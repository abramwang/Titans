declare module 'gridjs';
