export type ListMenuItemType = {
  value: string | number;
  title: string;
};
