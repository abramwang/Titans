<template>
  <label
    class="block w-full h-24 p-0 overflow-hidden border rounded-lg cursor-pointer border-slate-200 dark:border-zink-500"
  >
    <span class="flex flex-col h-full gap-1">
      <span class="flex items-center gap-1 p-1 bg-slate-100 dark:bg-zink-500">
        <span class="block p-1 ml-1 bg-white rounded dark:bg-zink-500"></span>
        <span
          class="block p-1 px-2 pb-0 bg-white dark:bg-zink-500 ms-auto"
        ></span>
        <span class="block p-1 px-2 pb-0 bg-white dark:bg-zink-500"></span>
      </span>
      <span class="block p-1 bg-slate-100 dark:bg-zink-500"></span>
      <span class="block p-1 mt-auto bg-slate-100 dark:bg-zink-500"></span>
    </span>
  </label>
</template>
