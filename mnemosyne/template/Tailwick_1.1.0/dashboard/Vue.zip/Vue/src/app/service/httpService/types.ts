export type UserType = {
  username: string;
  password: string;
  phone?: string;
  email?: string;
};
