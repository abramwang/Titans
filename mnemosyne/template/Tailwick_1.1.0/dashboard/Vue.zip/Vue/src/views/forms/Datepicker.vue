<script lang="ts" setup>
import DatePicker from "@/components/forms/datepicker/index.vue";
</script>
<template>
  <PageHeader title="Date Picker" :items="['Forms', 'Date Picker']" />
  <DatePicker />
</template>
