<script lang="ts" setup>
import BoxplotCharts from "@/components/apexcharts/boxplot/index.vue";
</script>
<template>
  <PageHeader
    title="Boxplot Charts"
    :items="['Apexcharts', 'Boxplot Charts']"
  />
  <BoxplotCharts />
</template>
