<script lang="ts" setup>
import Lightbox from "@/components/plugins/lightbox/index.vue";
</script>
<template>
    <PageHeader title="Lightbox" :items="['Plugins', 'Lightbox']" />
    <Lightbox />
</template>
