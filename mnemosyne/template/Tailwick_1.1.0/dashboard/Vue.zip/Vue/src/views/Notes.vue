<script lang="ts" setup>
import Notes from "@/components/notes/index.vue";
</script>
<template>
  <PageHeader title="Notes" :items="['Apps', 'Notes']" />
  <Notes />
</template>
