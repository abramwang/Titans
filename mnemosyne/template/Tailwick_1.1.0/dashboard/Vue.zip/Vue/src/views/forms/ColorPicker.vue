<script lang="ts" setup>
import ColorPicker from "@/components/forms/colorPicker/index.vue";
</script>
<template>
  <PageHeader title="Color Picker" :items="['Forms', 'Color Picker']" />
  <ColorPicker />
</template>
