<script lang="ts" setup>
import Tabs from "@/components/navigation/tabs/index.vue";
</script>
<template>
  <PageHeader title="Tabs" :items="['Navigation', 'Tabs']" />
  <Tabs />
</template>
