<script lang="ts" setup>
import Timepicker from "@/components/forms/timePicker/index.vue";
</script>
<template>
  <PageHeader title="Time Picker" :items="['Forms', 'Time Picker']" />
  <Timepicker />
</template>
