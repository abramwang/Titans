<script lang="ts" setup>
import FormValidation from "@/components/forms/formValidation/index.vue";
</script>
<template>
  <PageHeader title="Form Validation" :items="['Forms', 'Form Validation']" />
  <FormValidation />
</template>
