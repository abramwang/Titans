<script lang="ts" setup>
import RadialBarChart from "@/components/apexcharts/radialbar/index.vue";
</script>
<template>
  <PageHeader
    title="Radialbar Charts"
    :items="['Apexcharts', 'Radialbar Charts']"
  />
  <RadialBarChart />
</template>
