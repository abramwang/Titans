<script lang="ts" setup>
import DefaultCalendar from "@/components/calendar/month/index.vue";
</script>
<template>
  <PageHeader
    title="Monthly Calendar"
    :items="['Calendar', 'Monthly Calendar']"
  />
  <DefaultCalendar />
</template>
