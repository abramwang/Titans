<script lang="ts" setup>
import MixedChart from "@/components/apexcharts/mixed/index.vue";
</script>
<template>
  <PageHeader title="Mixed Charts" :items="['Apexcharts', 'Mixed Charts']" />
  <MixedChart />
</template>
