<script lang="ts" setup>
import Switch from "@/components/forms/switch/index.vue";
</script>
<template>
  <PageHeader title="Switch" :items="['Forms', 'Switch']" />
  <Switch />
</template>
