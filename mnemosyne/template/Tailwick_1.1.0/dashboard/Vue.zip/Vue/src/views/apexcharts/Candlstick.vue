<script lang="ts" setup>
import CandlstickChart from "@/components/apexcharts/candlstick/index.vue";
</script>
<template>
  <PageHeader
    title="Candlstick Charts"
    :items="['Apexcharts', 'Candlstick Charts']"
  />
  <CandlstickChart />
</template>
