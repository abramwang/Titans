<script lang="ts" setup>
import Ecommerce from "@/components/dashboard/eCommerce/index.vue"
</script>
<template>
    <PageHeader title="Ecommerce" :items="['Dashboards', 'Ecommerce']" />
    <Ecommerce />
</template>
