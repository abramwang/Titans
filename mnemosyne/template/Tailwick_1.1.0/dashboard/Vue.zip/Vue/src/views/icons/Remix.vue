<script lang="ts" setup>
import Remix from "@/components/icons/remix/index.vue";
</script>
<template>
  <PageHeader title="Remix Icons" :items="['Icons', 'Remix Icons']" />
  <Remix />
</template>
