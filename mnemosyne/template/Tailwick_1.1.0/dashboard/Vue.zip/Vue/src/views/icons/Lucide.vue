<script lang="ts" setup>
import Lucide from "@/components/icons/lucide/index.vue";
</script>
<template>
  <PageHeader title="Lucide Icons" :items="['Icons', 'Lucide Icons']" />
  <Lucide />
</template>
