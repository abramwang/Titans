<script lang="ts" setup>
import Mailbox from "@/components/mailbox/index.vue";
</script>
<template>
  <PageHeader title="Mailbox" :items="['Apps', 'Mailbox']" />
  <Mailbox />
</template>
