<script lang="ts" setup>
import HeatmapChart from "@/components/apexcharts/heatmap/index.vue";
</script>
<template>
  <PageHeader
    title="Heatmap Charts"
    :items="['Apexcharts', 'Heatmap Charts']"
  />
  <HeatmapChart />
</template>
