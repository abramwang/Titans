<script lang="ts" setup>
import RangeAreChart from "@/components/apexcharts/range-area/index.vue";
</script>
<template>
  <PageHeader
    title="Range Area Charts"
    :items="['Apexcharts', 'Range Area Charts']"
  />
  <RangeAreChart />
</template>
