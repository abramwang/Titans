<script lang="ts" setup>
import Balloon from "@/components/forms/editors/Balloon.vue";
</script>
<template>
  <PageHeader title="Balloon Editor" :items="['Forms', 'Balloon Editor']" />
  <Balloon />
</template>
