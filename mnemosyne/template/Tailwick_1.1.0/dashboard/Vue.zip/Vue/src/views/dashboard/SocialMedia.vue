<script lang="ts" setup>
import SocialMedia from "@/components/dashboard/social-media/index.vue"
</script>
<template>
    <SocialMedia />
</template>
