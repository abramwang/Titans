<script lang="ts" setup>
import Pagination from "@/components/navigation/pagination/index.vue";
</script>
<template>
  <PageHeader title="Pagination" :items="['Navigation', 'Pagination']" />
  <Pagination />
</template>
