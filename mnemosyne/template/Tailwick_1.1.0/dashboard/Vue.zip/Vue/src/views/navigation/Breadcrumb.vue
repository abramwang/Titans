<script lang="ts" setup>
import Breadcrumb from "@/components/navigation/breadcrumb/index.vue";
</script>
<template>
  <PageHeader title="Breadcrumb" :items="['Navigation', 'Breadcrumb']" />
  <Breadcrumb />
</template>
