<script lang="ts" setup>
import Wizard from "@/components/forms/wizard/index.vue";
</script>
<template>
  <PageHeader title="Register Wizard" :items="['Forms', 'Register Wizard']" />
  <Wizard />
</template>
