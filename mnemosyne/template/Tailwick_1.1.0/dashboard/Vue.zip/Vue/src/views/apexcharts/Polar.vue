<script lang="ts" setup>
import PolarChart from "@/components/apexcharts/polar/index.vue";
</script>
<template>
  <PageHeader title="Polar Charts" :items="['Apexcharts', 'Polar Charts']" />
  <PolarChart />
</template>
