<script lang="ts" setup>
import ScatterChart from "@/components/apexcharts/scatter/index.vue";
</script>
<template>
  <PageHeader
    title="Scatter Charts"
    :items="['Apexcharts', 'Scatter Charts']"
  />
  <ScatterChart />
</template>
