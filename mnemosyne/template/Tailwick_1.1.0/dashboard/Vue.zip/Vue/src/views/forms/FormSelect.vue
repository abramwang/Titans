<script lang="ts" setup>
import FormSelect from "@/components/forms/formSelect/index.vue";
</script>
<template>
  <PageHeader title="Form Select" :items="['Forms', 'Form Select']" />
  <FormSelect />
</template>
