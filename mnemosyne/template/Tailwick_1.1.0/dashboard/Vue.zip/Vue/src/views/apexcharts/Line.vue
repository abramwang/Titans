<script lang="ts" setup>
import LineChart from "@/components/apexcharts/line/index.vue";
</script>
<template>
  <PageHeader title="Line Charts" :items="['Apexcharts', 'Line Charts']" />
  <LineChart />
</template>
