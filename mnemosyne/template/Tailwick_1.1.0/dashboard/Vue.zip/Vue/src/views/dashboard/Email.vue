<script lang="ts" setup>
import Email from "@/components/dashboard/email/index.vue"
</script>
<template>
    <PageHeader title="Email Analytics" :items="['Dashboards', 'Email Analytics']" />
    <Email />
</template>
