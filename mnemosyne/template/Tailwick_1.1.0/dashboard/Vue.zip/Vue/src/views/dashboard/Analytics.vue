<script lang="ts" setup>
import Analytics from '@/components/dashboard/analytics/index.vue'
</script>
<template>
    <PageHeader title="Analytics" :items="['Dashboards', 'Analytics']" />
    <Analytics />
</template> 
