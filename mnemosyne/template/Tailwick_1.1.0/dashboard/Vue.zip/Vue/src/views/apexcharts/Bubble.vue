<script lang="ts" setup>
import BubbleCharts from "@/components/apexcharts/bubble/index.vue";
</script>
<template>
  <PageHeader title="Bubble Charts" :items="['Apexcharts', 'Bubble Charts']" />
  <BubbleCharts />
</template>
