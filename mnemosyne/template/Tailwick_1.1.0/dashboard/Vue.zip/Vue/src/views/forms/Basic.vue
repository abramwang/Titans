<script lang="ts" setup>
import Basic from "@/components/forms/basic/index.vue";
</script>
<template>
  <PageHeader title="Basic Elements" :items="['Forms', 'Basic Elements']" />
  <Basic />
</template>
