<script lang="ts" setup>
import ColumnChart from "@/components/apexcharts/column/index.vue";
</script>
<template>
  <PageHeader title="Column Charts" :items="['Apexcharts', 'Column Charts']" />
  <ColumnChart />
</template>
