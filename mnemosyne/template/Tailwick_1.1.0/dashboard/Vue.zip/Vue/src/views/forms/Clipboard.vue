<script lang="ts" setup>
import Clipboard from "@/components/forms/clipboard/index.vue";
</script>
<template>
  <PageHeader title="Clipboard" :items="['Forms', 'Clipboard']" />
  <Clipboard />
</template>
