<script lang="ts" setup>
import HR from "@/components/dashboard/hr/index.vue"
</script>
<template>
    <PageHeader title="HR" :items="['Dashboards', 'HR']" />
    <HR />
</template>
