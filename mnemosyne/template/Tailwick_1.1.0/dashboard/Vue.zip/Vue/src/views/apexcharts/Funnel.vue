<script lang="ts" setup>
import FunnelChart from "@/components/apexcharts/funnel/index.vue";
</script>
<template>
  <PageHeader title="Funnel Charts" :items="['Apexcharts', 'Funnel Charts']" />
  <FunnelChart />
</template>
