<script lang="ts" setup>
import MultiSelect from "@/components/forms/multiSelect/index.vue";
</script>
<template>
  <PageHeader title="Multi Select" :items="['Forms', 'Multi Select']" />
  <MultiSelect />
</template>
