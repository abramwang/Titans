<script lang="ts" setup>
import RadarChart from "@/components/apexcharts/radar/index.vue";
</script>
<template>
  <PageHeader title="Radar Charts" :items="['Apexcharts', 'Radar Charts']" />
  <RadarChart />
</template>
