<script lang="ts" setup>
import SwiperSlider from "@/components/plugins/swiperslider/index.vue";
</script>
<template>
    <PageHeader title="Swiper Slider" :items="['Plugins', 'Swiper Slider']" />
    <SwiperSlider />
</template>
