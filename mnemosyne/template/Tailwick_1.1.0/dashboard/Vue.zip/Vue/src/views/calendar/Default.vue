<script lang="ts" setup>
import DefaultCalendar from "@/components/calendar/default/index.vue";
</script>
<template>
  <PageHeader title="Calendar" :items="['Apps', 'Calendar']" />
  <DefaultCalendar />
</template>
