<script lang="ts" setup>
import Inline from "@/components/forms/editors/Inline.vue";
</script>
<template>
  <PageHeader title="Inline Editor" :items="['Forms', 'Inline Editor']" />
  <Inline />
</template>
