<script lang="ts" setup>
import TimelineChart from "@/components/apexcharts/timeline/index.vue";
</script>
<template>
    <PageHeader title="Timeline Charts" :items="['Apexcharts', 'Timeline Charts']" />
    <TimelineChart />
</template>
