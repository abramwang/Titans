<script lang="ts" setup>
import ClassicEditor from "@/components/forms/editors/Classic.vue";
</script>
<template>
  <PageHeader title="Classic Editor" :items="['Forms', 'Classic Editor']" />
  <ClassicEditor />
</template>
