<script lang="ts" setup>
import TreeMapChart from "@/components/apexcharts/treemap/index.vue";
</script>
<template>
  <PageHeader
    title="Treemap Charts"
    :items="['Apexcharts', 'Treemap Charts']"
  />
  <TreeMapChart />
</template>
