<script lang="ts" setup>
import Scrollhint from "@/components/plugins/scrollhint/index.vue";
</script>
<template>
    <PageHeader title="Scroll Hint" :items="['Plugins', 'Scroll Hint']" />
    <Scrollhint />
</template>
