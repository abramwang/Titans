<script lang="ts" setup>
import Chat from "@/components/chat/index.vue";
</script>
<template>
  <Chat />
</template>
