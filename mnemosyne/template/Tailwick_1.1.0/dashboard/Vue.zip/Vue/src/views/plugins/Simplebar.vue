<script lang="ts" setup>
import Simplebar from "@/components/plugins/simplebar/index.vue";
</script>
<template>
    <PageHeader title="Simplebar" :items="['Plugins', 'Simplebar']" />
    <Simplebar />
</template>
