<script lang="ts" setup>
import PieChart from "@/components/apexcharts/pie/index.vue";
</script>
<template>
  <PageHeader
    title="Pie/ Donut Charts"
    :items="['Apexcharts', 'Pie/ Donut Charts']"
  />
  <PieChart />
</template>
