<script lang="ts" setup>
import CheckboxRadio from "@/components/forms/checkboxRadio/index.vue";
</script>
<template>
  <PageHeader title="Checkbox & Radio" :items="['Forms', 'Checkbox & Radio']" />
  <CheckboxRadio />
</template>
