<script lang="ts" setup>
import BarCharts from "@/components/apexcharts/bar/index.vue";
</script>
<template>
  <PageHeader title="Bar Charts" :items="['Apexcharts', 'Bar Charts']" />
  <BarCharts />
</template>
