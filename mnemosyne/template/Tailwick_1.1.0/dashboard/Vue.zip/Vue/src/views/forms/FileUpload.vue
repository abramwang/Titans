<script lang="ts" setup>
import FileUpload from "@/components/forms/fileUpload/index.vue";
</script>
<template>
  <PageHeader title="File Upload" :items="['Forms', 'File Upload']" />
  <FileUpload />
</template>
