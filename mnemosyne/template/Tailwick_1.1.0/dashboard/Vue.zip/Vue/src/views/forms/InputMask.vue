<script lang="ts" setup>
import InputMask from "@/components/forms/inputMask/index.vue";
</script>
<template>
  <PageHeader title="Input Mask" :items="['Forms', 'Input Mask']" />
  <InputMask />
</template>
