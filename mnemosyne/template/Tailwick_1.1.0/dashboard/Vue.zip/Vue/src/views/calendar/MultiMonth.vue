<script lang="ts" setup>
import DefaultCalendar from "@/components/calendar/multi/index.vue";
</script>
<template>
  <PageHeader
    title="Monthly Calendar"
    :items="['Calendar', 'Monthly Calendar']"
  />
  <DefaultCalendar />
</template>
