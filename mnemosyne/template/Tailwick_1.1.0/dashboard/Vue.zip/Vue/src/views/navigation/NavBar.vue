<script lang="ts" setup>
import NavBar from "@/components/navigation/navBar/index.vue";
</script>
<template>
  <PageHeader title="Navbar" :items="['Navigation', 'Navbar']" />
  <NavBar />
</template>
