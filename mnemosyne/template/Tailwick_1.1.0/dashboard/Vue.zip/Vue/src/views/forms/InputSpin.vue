<script lang="ts" setup>
import InputSpin from "@/components/forms/inputSpin/index.vue";
</script>
<template>
  <PageHeader title="Input Spin" :items="['Forms', 'Input Spin']" />
  <InputSpin />
</template>
