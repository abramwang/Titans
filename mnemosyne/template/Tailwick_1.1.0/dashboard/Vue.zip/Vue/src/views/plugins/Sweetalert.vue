<script lang="ts" setup>
import Sweetalert from "@/components/plugins/sweetAlert/index.vue";
</script>
<template>
    <PageHeader title="Sweetalert" :items="['Plugins', 'Sweetalert']" />
    <Sweetalert />
</template>
