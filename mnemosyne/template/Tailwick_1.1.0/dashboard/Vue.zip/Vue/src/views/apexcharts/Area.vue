<script lang="ts" setup>
import AreaCharts from "@/components/apexcharts/area/index.vue";
</script>
<template>
  <PageHeader title="Area Charts" :items="['Apexcharts', 'Area Charts']" />
  <AreaCharts />
</template>
