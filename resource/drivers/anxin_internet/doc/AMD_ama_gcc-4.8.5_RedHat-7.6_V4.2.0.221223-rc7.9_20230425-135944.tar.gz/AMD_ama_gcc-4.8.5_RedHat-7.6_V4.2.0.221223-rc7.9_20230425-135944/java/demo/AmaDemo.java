/**
 * @file         ama_test.java
 * @breif        TODO
 * @mail         guoguangkui@archforce.com.cn
 * @created time Mon 27 Nov 2017 02:33:53 PM CST
 */

package demo.ama;
import java.text.SimpleDateFormat;
import java.util.*;
import java.io.*;
import sun.misc.*;
import com.archforce.amd.ama.*;
import java.math.BigInteger;


public class AmaDemo {

    public static volatile boolean isRunning = true;

    static
    {
        System.loadLibrary("ama_java");
    }

    //日志打印
    static void log(int level, String title, String log) {

        String levelString = new String();
        if(level == LogLevel.kTrace) levelString = " Trace ";
        else if(level == LogLevel.kDebug) levelString = " Debug ";
        else if(level == LogLevel.kInfo) levelString = " Info ";
        else if(level == LogLevel.kWarn) levelString = " Warn ";
        else if(level == LogLevel.kError) levelString = " Error ";
        else if(level == LogLevel.kFatal) levelString = " Fatal ";

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

        System.out.println(df.format(new Date()) + levelString + "| " + title + " | "+ log);
    }

    //代码表请求代码示例
    static public long getCodeTable() {
        CodeTableRecordList recordlist = new CodeTableRecordList();

        // 预先分配2条查询信息的items数组空间(数组空间在没有初始化的情况下,里面的值是不确定的,查询信息上送时可能会与预期不符)
        SubCodeTableItem items = Tools.createSubCodeTableItem(2);

        SubCodeTableItem item1 = new SubCodeTableItem();                    // 查询信息1(查询深交所“000001”的代码表数据),查询的详细规则见配套开发指南。
        item1.setMarket(MarketType.kSZSE);
        item1.setSecurityCode("000001");
        Tools.setSubCodeTableItem(items, 0, item1);                         // 初始化items数组的第0位内存空间

        SubCodeTableItem item2 = new SubCodeTableItem();                    // 查询信息2(查询上交所“600000”的代码表数据),查询的详细规则见配套开发指南。
        item2.setMarket(MarketType.kSSE);
        item2.setSecurityCode("600000");
        Tools.setSubCodeTableItem(items, 1, item2);                         // 初始化items数组的第1位内存空间
        
        boolean result = IAMDApi.getCodeTableList(recordlist, items, 2);    // 发起查询,上送items[0]和items[1]的查询信息；查询后的数据通过recordlist返回
        if (result) {
            long listNums = recordlist.getListNums();                       // 获取数据条数
            CodeTableRecord records = recordlist.getRecords();              // 获取代码表数据
            for (int i = 0; i < listNums; ++i) {
                //获取一条代码表数据record
                CodeTableRecord record = Tools.getDataByIndex(records, i);

                /* TODO */
                //获取到代码表信息后,可以根据需求对代码表信息进行处理
                System.out.println(Tools.serialize(record));
            }

            //records使用完后需要手动释放内存
            if(listNums > 0)
            {
                Tools.freeMemory(records);
                return listNums;
            }
        }

        // 查询调用完后释放items空间
        Tools.destroySubCodeTableItem(items);
        return 0;
    }

    //etf 代码表请求代码示例
    static public long getETFCodeTable() {
        ETFCodeTableRecordList recordlist = new ETFCodeTableRecordList();

        // 预先分配2条查询信息的etfItems数组空间(数组空间在没有初始化的情况下,里面的值是不确定的,查询信息上送时可能会与预期不符)
        ETFItem etfItems = Tools.createETFItem(2);

        ETFItem etfItem1 = new ETFItem();                                           // 查询信息1(查询深交所全部代码的ETF代码表数据),查询的详细规则见配套开发指南。
        etfItem1.setMarket(MarketType.kSZSE);
        etfItem1.setSecurityCode("");
        Tools.setETFItem(etfItems, 0, etfItem1);                                    // 初始化etfItems数组的第0位内存空间

        ETFItem etfItem2 = new ETFItem();                                           // 查询信息2(查询上交所全部代码的ETF代码表数据),查询的详细规则见配套开发指南。
        etfItem2.setMarket(MarketType.kSSE);
        etfItem2.setSecurityCode("");
        Tools.setETFItem(etfItems, 1, etfItem2);                                    // 初始化etfItems数组的第1位内存空间
        
        boolean result = IAMDApi.getETFCodeTableList(recordlist, etfItems, 2);      // 发起查询,上送etfItems[0]和etfItems[1]的查询信息；查询后的数据通过recordlist返回
        if (result) {
            long listNums = recordlist.getEtfListNums();
            ETFCodeTableRecord records = recordlist.getEtfRecords();
            for (int i = 0; i < listNums; ++i) {
                // 获取一条ETF代码表数据record
                ETFCodeTableRecord record = Tools.getDataByIndex(records, i);

                /* TODO */
                // 获取到ETF代码表信息后,可以根据需求对ETF代码表信息进行处理
                System.out.println(Tools.serialize(record));
            }

            // records使用完后需要手动释放内存
            if(listNums > 0)
            {
                Tools.freeMemory(records);
                return listNums;
            }
        }

        // 查询调用完后释放etfItems空间
        Tools.destroyETFItem(etfItems);
        return 0;
    }

    //国际市场港股汇率数据获取示例
    static public long getIMCExchangeRateData() {
        IMCExchangeRateList list = new IMCExchangeRateList();

        boolean ret = IAMDApi.getIMCExchangeRate(list);
        if(ret){
            long list_num = list.getImcListNums();
            IMCExchangeRate rate_datas = list.getImcRateData();
            for (int i = 0; i < list_num; ++i) {
                //获取一条国际市场港股汇率数据record
                IMCExchangeRate rate_data = Tools.getDataByIndex(rate_datas, i);

                /* TODO */
                //获取到国际市场港股汇率数据后,可以根据需求对数据进行处理
                System.out.println(Tools.serialize(rate_data));
            }

            // records使用完后需要手动释放内存
            if(list_num > 0)
            {
                Tools.freeMemory(rate_datas);
                return list_num;
            }
        }

        return 0;
    }

    //RDI数据获取示例
    static public long getRDIData() {
        //预先分配2条查询信息的rdiItems数组空间(数组空间在没有初始化的情况下,里面的值是不确定的,查询信息上送时可能会与预期不符)
        RDIQueryItem rdiItems = Tools.createRDIQueryItem(2);

        RDIQueryItem rdiItem1 = new RDIQueryItem();         //查询信息1(查询代码"010011"的RDI数据,代码为空时("")表示订阅所有代码)
        rdiItem1.setSecurityCode("010011");
        Tools.setRDIQueryItem(rdiItems, 0, rdiItem1);       //设置rdiItems数组的第0位内存空间

        RDIQueryItem rdiItem2 = new RDIQueryItem();         //查询信息2(查询代码"010214"的RDI数据,代码为空时("")表示订阅所有代码)
        rdiItem2.setSecurityCode("010214");
        Tools.setRDIQueryItem(rdiItems, 1, rdiItem2);       //设置rdiItems数组的第0位内存空间

        // 获取RDI信息
        /*
        获取债券信息(银行间) BondInfoInterbankList/getBondInfoInterbank
        获取资产支持证券信息(ABS) ABSInfoList/getABSInfo
        获取资产支持证券历史信息(ABS历史) ABSHistoryInfoList/getABSHistoryInfo
        获取资产支持证券信用评级数据 ABSCreditRatingsList/getABSCreditRatings
        获取预发行债券信息数据 PreIssuedBondInfoList/getPreIssuedBondInfo
        获取上市前债券信息(银行间)数据 PreIPOBondInfoList/getPreIPOBondInfo
        获取可交易债券信息数据 XBondTradeBondInfoList/getXBondTradeBondInfo
        获取质押券折算率(匿名点击)信息 PledgedConvertRateACInfoList/getPledgedConvertRateACInfo
        获取X-Repo 分层报价群组信息数据 XRepoHierQuoteGroupInfoList/getXRepoHierQuoteGroupInfo(没有代码信息,接口无item参数)
        获取X-Repo 合约信息数据 XRepoContractInfoList/getXRepoContractInfo
        获取利率互换(固浮)信息数据 SwapFixedFloatInfoList/getSwapFixedFloatInfo
        获取利率互换(固浮)期差基差合约信息数据 SwapFixedFloatBasisContractInfoList/getSwapFixedFloatBasisContractInfo
        */

        BondInfoInterbankList recordlist = new BondInfoInterbankList();
        boolean result = IAMDApi.getBondInfoInterbank(recordlist, rdiItems, 2);     //获取RDI数据

        if (result) {
            long listNums = recordlist.getDataCnt();
            MDBondInfoInterbank records = recordlist.getData();
            for (long i = 0; i < listNums; ++i) {
                //获取一条RDI数据record
                MDBondInfoInterbank record = Tools.getDataByIndex(records, i);
                
                /* TODO */
                //获取到RDI数据后,可以根据需求对数据进行处理
                System.out.println(Tools.serialize(record));
            }

            // records使用完后需要手动释放内存
            if(listNums > 0)
            {
                Tools.freeMemory(records);
                return listNums;
            }
        }

        //订阅调用完后释放rdiItems空间
        Tools.destroyRDIQueryItem(rdiItems);
        return 0;
    }

    //数据权限订阅示例代码
    static public void subscribeWithDataAuth() {
        /*
            按照权限订阅信息设置:
            1. 订阅信息分三个维度(对应关系见配套开发指南附录1):
                setMarket():设置订阅的市场
                setFlag():设置订阅的权限数据类型
                setSecurityCode():设置订阅的代码
            2. 订阅操作有三种:
                kSet 设置订阅, 新的订阅会覆盖之前的所有订阅信息
                kAdd 增加订阅, 在前一个基础上增加订阅信息
                kDel 删除订阅, 在前一个基础上删除订阅信息
                kCancelAll 取消所有订阅信息
        */

        //创建2个存储订阅代码信息的subItems数组空间(数组空间在没有初始化的情况下,里面的值是不确定的,订阅上送时可能会导致订阅与预期不符)
        SubscribeItem subItems = Tools.createSubscribeItem(2);

        SubscribeItem subItem1 = new SubscribeItem();   //订阅信息1(订阅深交所000001代码的快照和逐笔委托)
        subItem1.setMarket(MarketType.kSZSE);
        int flag = SubscribeDataType.kSnapshot.intValue() | SubscribeDataType.kTickOrder.intValue();
        BigInteger Iflag = new BigInteger(String.valueOf(flag));
        subItem1.setFlag(Iflag);
        subItem1.setSecurityCode("000001");
        Tools.setSubscribeItem(subItems, 0, subItem1);  //初始化subItems数组的第0位内存空间

        SubscribeItem subItem2 = new SubscribeItem();   //订阅信息2(订阅上交所600000单只证券的全部数据)
        subItem2.setMarket(MarketType.kSSE);
        subItem2.setFlag(SubscribeDataType.kNone);
        subItem2.setSecurityCode("600000");
        Tools.setSubscribeItem(subItems, 1, subItem2);  //初始化subItems数组的第1位内存空间

        /*
            以kSet发起订阅,设置两条订阅信息(此前所有已设置好的订阅信息都将会被覆盖)
            因为发起订阅的数量为2,因此会上送subItems[0]和subItems[1]的订阅信息
            订阅结果：
                深交所000001证券代码的快照和逐笔委托 + 上交所600000证券代码的全部数据
        */
        int ret = IAMDApi.subscribeData(SubscribeType.kSet, subItems, 2);
        if(ret == ErrorCode.kSuccess) {
            log(LogLevel.kInfo, "subscribeWithDataAuth", "Set subscribe with data_auth success");
        }
        else {
            log(LogLevel.kError, "subscribeWithDataAuth", "Set subscribe with data_auth failed");
            return ;
        }

        //kAdd、kDel、kCancelAll订阅操作示例,可根据需求调用
        if(false)
        {
            SubscribeItem subItem3 = new SubscribeItem();   //订阅信息3(订阅深圳市场000002代码的快照)
            subItem3.setMarket(MarketType.kSZSE);
            subItem3.setFlag(SubscribeDataType.kSnapshot);
            subItem3.setSecurityCode("000002");
            Tools.setSubscribeItem(subItems, 0, subItem3);  //设置subItems数组的第0位内存空间

            /*
                以kAdd方式发起订阅,在已有基础上增加一条订阅信息
                因为发起订阅的数量为1,因此最终只会上送subItems[0]的订阅信息
                订阅结果：
                    深交所000001代码的快照和逐笔委托 +  深交所000002代码的快照 + 上交所600000单只证券的全部数据
            */
            ret = IAMDApi.subscribeData(SubscribeType.kAdd, subItems, 1);
            if(ret == ErrorCode.kSuccess) {
                log(LogLevel.kInfo, "subscribeWithDataAuth", "Add subscribe with data_auth success");
            }
            else {
                log(LogLevel.kError, "subscribeWithDataAuth", "Add subscribe with data_auth failed");
                return ;
            }

            /*
                以kDel发起订阅,在已有基础上删除一条订阅信息
                因为发起订阅的数量为1,因此最终只会上送subItems[0]的订阅信息
                订阅结果：
                    深交所000001代码的快照和逐笔委托 + 上交所600000单只证券的全部数据
            */
            ret = IAMDApi.subscribeData(SubscribeType.kDel, subItems, 1);
            if(ret == ErrorCode.kSuccess) {
                log(LogLevel.kInfo, "subscribeWithDataAuth", "Del subscribe with data_auth success");
            }
            else {
                log(LogLevel.kError, "subscribeWithDataAuth", "Del subscribe with data_auth failed");
                return ;
            }

            /*
                以kCancelAll发起订阅,取消所有订阅信息
                订阅结果：
                    无
            */
            ret = IAMDApi.subscribeData(SubscribeType.kCancelAll, subItems, 2);
            if(ret == ErrorCode.kSuccess) {
                log(LogLevel.kInfo, "subscribeWithDataAuth", "CancelAll subscribe with data_auth success");
            }
            else {
                log(LogLevel.kError, "subscribeWithDataAuth", "CancelAll subscribe with data_auth failed");
                return ;
            }
        }

        //订阅调用完后释放subItems空间
        Tools.destroySubscribeItem(subItems);
        return ;
    }

    //品种订阅示例代码
    static public void subscribeWithCategory() {
        /*
            按品种类型订阅信息设置:
            1. 订阅信息分三个维度：
                setMarket():设置订阅的市场
                setDataType():设置订阅的证券数据类型
                setCategoryType():设置订阅的品种类型
                setSecurityCode():设置订阅的代码
            2. 订阅操作有三种:
                kSet 设置订阅, 新的订阅会覆盖之前的所有订阅信息
                kAdd 增加订阅, 在前一个基础上增加订阅信息
                kDel 删除订阅, 在前一个基础上删除订阅信息
                kCancelAll 取消所有订阅信息
        */

        //创建2个存储订阅代码信息的subItems数组空间(数组空间在没有初始化的情况下,里面的值是不确定的,订阅上送时可能会导致订阅与预期不符)
        SubscribeCategoryItem subItems = Tools.createSubscribeCategoryItem(2);

        SubscribeCategoryItem subItem1 = new SubscribeCategoryItem();   //订阅信息1(订阅深交所所有代码的股票快照)
        subItem1.setMarket(MarketType.kSZSE);
        subItem1.setDataType(SubscribeSecuDataType.kSnapshot);
        subItem1.setCategoryType(SubscribeCategoryType.kStock);
        subItem1.setSecurityCode("");
        Tools.setSubscribeCategoryItem(subItems, 0, subItem1);          //初始化subItems数组的第0位内存空间

        SubscribeCategoryItem subItem2 = new SubscribeCategoryItem();   //订阅信息2(订阅上交所所有代码的指数快照)
        subItem2.setMarket(MarketType.kSSE);
        subItem2.setDataType(SubscribeSecuDataType.kSnapshot);
        subItem2.setCategoryType(SubscribeCategoryType.kIndex);
        subItem2.setSecurityCode("");
        Tools.setSubscribeCategoryItem(subItems, 1, subItem2);           //初始化subItems数组的第1位内存空间

        /*
            以kSet发起订阅,设置两条订阅信息(此前所有已设置好的订阅信息都将会被覆盖)
            因为发起订阅的数量为2,因此会上送subItems[0]和subItems[1]的订阅信息
            订阅结果：
                深交所所有代码的股票快照 + 上交所所有代码的指数快照
        */
        int ret = IAMDApi.subscribeData(SubscribeType.kSet, subItems, 2);
        if(ret == ErrorCode.kSuccess) {
            log(LogLevel.kInfo, "subscribeWithCategory", "Set subscribe with category success");
        }
        else {
            log(LogLevel.kError, "subscribeWithCategory", "Set subscribe with category failed");
            return ;
        }

        // kAdd、kDel、kCancelAll订阅操作示例,可根据需求调用
        if(false)
        {
            SubscribeCategoryItem subItem3 = new SubscribeCategoryItem();   //订阅信息3(订阅深交所所有代码的基金逐笔委托)
            subItem3.setMarket(MarketType.kSZSE);
            subItem3.setDataType(SubscribeSecuDataType.kTickOrder);
            subItem3.setCategoryType(SubscribeCategoryType.kFund);
            subItem3.setSecurityCode("");
            Tools.setSubscribeCategoryItem(subItems, 0, subItem3);          //设置subItems数组的第0位内存空间

            /*
                以kAdd方式发起订阅,在已有基础上增加一条订阅信息
                因为发起订阅的数量为1,因此最终只会上送subItems[0]的订阅信息
                订阅结果：
                    深交所所有代码的股票快照 + 深交所所有代码的基金逐笔委托 + 上交所所有代码的指数快照
            */
            ret = IAMDApi.subscribeData(SubscribeType.kAdd, subItems, 1);
            if(ret == ErrorCode.kSuccess) {
                log(LogLevel.kInfo, "subscribeWithCategory", "Add subscribe with category success");
            }
            else {
                log(LogLevel.kError, "subscribeWithCategory", "Add subscribe with category failed");
                return ;
            }

            /*
                以kDel方式发起订阅,在已有基础上增加一条订阅信息
                因为发起订阅的数量为1,因此最终只会上送subItems[0]的订阅信息
                订阅结果：
                    深交所所有代码的股票快照 + 上交所所有代码的指数快照
            */
            ret = IAMDApi.subscribeData(SubscribeType.kDel, subItems, 1);
            if(ret == ErrorCode.kSuccess) {
                log(LogLevel.kInfo, "subscribeWithCategory", "Del subscribe with category success");
            }
            else {
                log(LogLevel.kError, "subscribeWithCategory", "Del subscribe with category failed");
                return ;
            }

            /*
                以kCancelAll发起订阅,取消所有订阅信息
                订阅结果：
                    无
            */
            ret = IAMDApi.subscribeData(SubscribeType.kCancelAll, subItems, 2);
            if(ret == ErrorCode.kSuccess) {
                log(LogLevel.kInfo, "subscribeWithDataAuth", "CancelAll subscribe with category success");
            }
            else {
                log(LogLevel.kError, "subscribeWithDataAuth", "CancelAll subscribe with category failed");
                return ;
            }
        }

        //订阅调用完后释放subItems空间
        Tools.destroySubscribeCategoryItem(subItems);
        return ;
    }

    // 委托簿数据订阅示例,此接口后续逐步弃用, 用subscribeDerivedData接口替代
    static public void subscribeOrderBook() {
        // 创建2个存储订阅代码信息的orderItems数组空间(数组空间在没有初始化的情况下,里面的值是不确定的,订阅上送时可能会导致订阅与预期不符)
        SubscribeOrderBookItem orderItems = Tools.createSubscribeOrderBookItem(2);

        SubscribeOrderBookItem orderItem1 = new SubscribeOrderBookItem();    //订阅信息1(订阅上交所"600000"证券代码的委托簿数据)
        orderItem1.setMarket(MarketType.kSSE);
        orderItem1.setFlag(SubscribeOrderBookDataType.kOrderBook);
        orderItem1.setSecurityCode("600000");
        Tools.setSubscribeOrderBookItem(orderItems, 0, orderItem1);          //初始化orderItems数组的第0位内存空间

        SubscribeOrderBookItem orderItem2 = new SubscribeOrderBookItem();    //订阅信息2(订阅深交所"000001"证券的委托簿数据 & 委托簿快照数据 )
        orderItem2 = new SubscribeOrderBookItem();
        orderItem2.setMarket(MarketType.kSZSE);
        orderItem2.setFlag(SubscribeOrderBookDataType.kNone);
        orderItem2.setSecurityCode("000001");
        Tools.setSubscribeOrderBookItem(orderItems, 1, orderItem2);          //初始化orderItems数组的第0位内存空间

        /*
            以kSet发起订阅,设置两条订阅信息(此前所有已设置好的订阅信息都将会被覆盖)
            因为发起订阅的数量为2,因此会上送orderItems[0]和orderItems[1]的订阅信息
            订阅结果：
               上交所"600000"证券代码的委托簿数据 + 订阅深交所"000001"证券的委托簿数据 & 委托簿快照数据
        */
        int ret = IAMDApi.subscribeOrderBookData(SubscribeType.kSet, orderItems, 2);
        if(ret == ErrorCode.kSuccess) {
            log(LogLevel.kInfo, "subscribeOrderBook", "Set subscribe order_book success");
        }
        else {
            log(LogLevel.kError, "subscribeOrderBook", "Set subscribe order_book failed");
            return ;
        }

        // kAdd、kDel、kCancelAll订阅操作示例,可根据需求调用
        if(false)
        {
            SubscribeOrderBookItem orderItem3 = new SubscribeOrderBookItem();    //订阅信息3(订阅上交所"600001"证券代码的委托簿数据)
            orderItem3.setMarket(MarketType.kSSE);
            orderItem3.setFlag(SubscribeOrderBookDataType.kOrderBook);
            orderItem3.setSecurityCode("600001");
            Tools.setSubscribeOrderBookItem(orderItems, 0, orderItem3);          //设置orderItems数组的第0位内存空间

            /*
                以kAdd方式发起订阅,在已有基础上增加一条订阅信息
                因为发起订阅的数量为1,因此最终只会上送orderItems[0]的订阅信息
                订阅结果：
                    上交所"600000"证券代码的委托簿数据 + 上交所"600001"证券代码的委托簿数据 + 订阅深交所"000001"证券的委托簿数据 & 委托簿快照数据
            */
            ret = IAMDApi.subscribeOrderBookData(SubscribeType.kAdd, orderItems, 1);
            if(ret == ErrorCode.kSuccess) {
                log(LogLevel.kInfo, "subscribeOrderBook", "Add subscribe order_book success");
            }
            else {
                log(LogLevel.kError, "subscribeOrderBook", "Add subscribe order_book failed");
                return ;
            }

            /*
                以kDel方式发起订阅,在已有基础上增加一条订阅信息
                因为发起订阅的数量为1,因此最终只会上送orderItems[0]的订阅信息
                订阅结果：
                    上交所"600000"证券代码的委托簿数据 + 订阅深交所"000001"证券的委托簿数据 & 委托簿快照数据
            */
            ret = IAMDApi.subscribeOrderBookData(SubscribeType.kDel, orderItems, 1);
            if(ret == ErrorCode.kSuccess) {
                log(LogLevel.kInfo, "subscribeOrderBook", "Del subscribe order_book success");
            }
            else {
                log(LogLevel.kError, "subscribeOrderBook", "Del subscribe order_book failed");
                return ;
            }

            /*
                以kCancelAll发起订阅,取消所有订阅信息
                订阅结果：
                    无
            */
            ret = IAMDApi.subscribeOrderBookData(SubscribeType.kDel, orderItems, 2);
            if(ret == ErrorCode.kSuccess) {
                log(LogLevel.kInfo, "subscribeOrderBook", "CancelAll subscribe order_book success");
            }
            else {
                log(LogLevel.kError, "subscribeOrderBook", "CancelAll subscribe order_book failed");
                return ;
            }
        }

        Tools.destroySubscribeOrderBookItem(orderItems);
        return ;
    }

    // 行情衍生数据订阅示例
    static public void subscribeDerivedData() {
        // 创建2个存储订阅代码信息的derivedItems数组空间(数组空间在没有初始化的情况下,里面的值是不确定的,订阅上送时可能会导致订阅与预期不符)
        SubscribeDerivedDataItem derivedItems = Tools.createSubscribeDerivedDataItem(2);

        SubscribeDerivedDataItem derivedItem1 = new SubscribeDerivedDataItem();      //订阅信息1(订阅上交所"510020"证券代码)
        derivedItem1.setMarket(MarketType.kSSE);
        derivedItem1.setSecurityCode("510020");
        Tools.setSubscribeDerivedDataItem(derivedItems, 0, derivedItem1);            //初始化derivedItems数组的第0位内存空间

        SubscribeDerivedDataItem derivedItem2 = new SubscribeDerivedDataItem();      //订阅信息2(订阅深交所"159930"证券代码)
        derivedItem2.setMarket(MarketType.kSZSE);
        derivedItem2.setSecurityCode("159930");
        Tools.setSubscribeDerivedDataItem(derivedItems, 1, derivedItem2);            //初始化derivedItems数组的第1位内存空间

        /*
            以kSet发起订阅,设置两条订阅信息(此前所有已设置好的订阅信息都将会被覆盖),订阅数据类型见对应开发指南
            因为发起订阅的数量为2,因此会上送derivedItems[0]和derivedItems[1]的订阅信息
            订阅结果：
               上交所"510020"证券代码的IOPV快照数据 + 深交所"159930"证券代码的IOPV快照数据
        */
        int ret = IAMDApi.subscribeDerivedData(SubscribeType.kSet, SubscribeDerivedDataType.kIOPVSnapshot, derivedItems, 2);
        if(ret == ErrorCode.kSuccess) {
            log(LogLevel.kInfo, "subscribeDerivedData", "Set subscribe derived data success");
        }
        else {
            log(LogLevel.kError, "subscribeDerivedData", "Set subscribe derived data failed");
            return ;
        }

        // kAdd、kDel、kCancelAll订阅操作示例,可根据需求调用
        if(false)
        {
            /*
                以kAdd发起订阅,在已有基础上增加两条订阅信息,订阅数据类型见对应开发指南
                因为发起订阅的数量为2,因此会上送derivedItems[0]和derivedItems[1]的订阅信息
                订阅结果：
                上交所"510020"证券代码的IOPV快照数据 & 委托簿快照数据 + 深交所"159930"证券代码的IOPV快照数据 & 委托簿快照数据
            */
            ret = IAMDApi.subscribeDerivedData(SubscribeType.kAdd, SubscribeDerivedDataType.kOrderBookSnapshot, derivedItems, 2);
            if(ret == ErrorCode.kSuccess) {
                log(LogLevel.kInfo, "subscribeDerivedData", "Add subscribe derived data success");
            }
            else {
                log(LogLevel.kError, "subscribeDerivedData", "Add subscribe derived data failed");
                return ;
            }

            /*
                以kDel发起订阅,在已有基础上删除一条订阅信息,订阅数据类型见对应开发指南
                因为发起订阅的数量为1,因此会上送derivedItems[0]的订阅信息
                订阅结果：
                上交所"510020"证券代码的IOPV快照数据 + 深交所"159930"证券代码的IOPV快照数据 & 委托簿快照数据
            */
            ret = IAMDApi.subscribeDerivedData(SubscribeType.kDel, SubscribeDerivedDataType.kOrderBookSnapshot, derivedItems, 1);
            if(ret == ErrorCode.kSuccess) {
                log(LogLevel.kInfo, "subscribeDerivedData", "Del subscribe derived data success");
            }
            else {
                log(LogLevel.kError, "subscribeDerivedData", "Del subscribe derived data failed");
                return ;
            }

            /*
                以kCancelAll发起订阅,取消所有订阅信息
                订阅结果：
                    无
            */
            ret = IAMDApi.subscribeDerivedData(SubscribeType.kCancelAll, SubscribeDerivedDataType.kOrderBookSnapshot, derivedItems, 2);
            if(ret == ErrorCode.kSuccess) {
                log(LogLevel.kInfo, "subscribeDerivedData", "CancelAll subscribe derived data success");
            }
            else {
                log(LogLevel.kError, "subscribeDerivedData", "CancelAll subscribe derived data failed");
                return ;
            }
        }

        //订阅调用完后释放derivedItems空间
        Tools.destroySubscribeDerivedDataItem(derivedItems);
    }

    public static void main(String[] args) {

        SignalHandler handler = new SignalHandler() {
        
            public void handle(Signal sig) {
                isRunning = false; 
                System.out.println("AMA Info The isRunning is trun to " + isRunning);
            }
        };

        Signal.handle(new Signal("INT"), handler);
        Signal.handle(new Signal("TERM"), handler);

        //设置初始化信息
        Cfg cfg = new Cfg();
        /*
            通道模式设置及各个通道说明:
            cfg.setChannelMode(ChannelMode.kTCP);    //TCP 方式计入上游行情系统
            cfg.setChannelMode(ChannelMode.kAMI);    //AMI 组播方式接入上游行情系统
            cfg.setChannelMode(ChannelMode.kRDMA);   //开启硬件加速RDMA通道,抓取网卡数据包数据
            cfg.setChannelMode(ChannelMode.kEXA);    //开启硬件加速EXA通道,抓取网卡数据包数据
            cfg.setChannelMode(ChannelMode.kPCAP);   //开启硬件加速PCAP通道,抓取网卡数据包数据
            cfg.setChannelMode(ChannelMode.kMDDP);   //直接接入交易所网关组播数据,现在只有深圳交易所开通了此服务
            cfg.setChannelMode(ChannelMode.kFPGA);   //FPGA接入数据
            cfg.setChannelMode(ChannelMode.kUDP);    //AMD组播方式获取数据
            
            int mode = ChannelMode.kTCP.intValue()|ChannelMode.kAMI.intValue();
            BigInteger IMode = new BigInteger(String.valueOf(mode));
            cfg.setChannelMode(IMode);   //同时通过TCP方式和AMI组播方式接入上游,通过cfg.ha_mode 设置对应的高可用设置模式
        */
        cfg.setChannelMode(ChannelMode.kTCP);

        cfg.setTcpCompressMode(0); //TCP传输数据方式: 0 不压缩 1 华锐自定义压缩 2 zstd压缩(仅TCP模式有效)

        /*
            通道高可用模式设置
            1. ChannelMode 为单通道时,建议设置值为kMasterSlaveA / kMasterSlaveB
            2. ChannelMode 混合开启多个通道时,根据需求设置不同的值
                1) 如果需要多个通道为多活模式接入,请设置kRegularDataFilter值
                2) 如果需要多个通道互为主备接入,请设置值为kMasterSlaveA / kMasterSlaveB,kMasterSlaveA / kMasterSlaveB 差别请参看注释说明
                通道优先级从高到低依次为 kRDMA/kEXA/kMDDP/kAMI/kTCP/kPCAP
        */
        cfg.setHaMode(HighAvailableMode.kMasterSlaveA);

        cfg.setMinLogLevel(LogLevel.kInfo); // 设置日志最小级别：Info级, AMA内部日志通过 OnLog 回调函数返回
        
        /*
            设置是否输出监控数据: true(是), false(否), 监控数据通过OnIndicator 回调函数返回
            监控数据格式为json, 主要监控数据包括订阅信息,数据接收数量统计
            数据量统计:包括接收数量和成功下发的数量统计,两者差值为过滤的数据量统计
            eg: "RecvSnapshot": "5926", "SuccessSnapshot": "5925",表示接收了快照数据5926个,成功下发5925个,过滤数据为 5926 - 5925 = 1 个
                过滤的数据有可能为重复数据或者非订阅数据
        */
        cfg.setIsOutputMonData(false);

        /*
            设置逐笔保序开关: true(开启保序功能) , false(关闭保序功能),现阶段只对MDDP通道和委托簿本地构建生效
            主要校验逐笔成交数据和逐笔委托数据是否有丢失,如果丢失会有告警日志,缓存逐笔数据并等待KeepOrderTimeout(单位ms)时间等待上游数据重传,
            如果超过此时间,直接下发缓存数据,默认数据已经丢失,如果之后丢失数据过来也会丢弃。
            同时由于深圳和上海交易所都是通道内序号连续,如果打开了保序开关,必须订阅全部代码的逐笔数据,否则一部分序号会被订阅过滤,导致数据超时等待以及丢失告警。
        */
        cfg.setKeepOrder(false);
        cfg.setKeepOrderTimeoutMs(3000);

        cfg.setIsSubscribeFull(false); //设置默认订阅: true 代表默认全部订阅, false 代表默认全部不订阅

        /*
        委托簿千档行情参数设置(仅委托簿版本API有效,若非委托簿版本参数设置无效):
            1) 行情输出设置,包括档位数量以及每档对应的委托队列数量
            2)委托簿计算输出参数设置,包括线程数量以及递交间隔设置
        */
        cfg.setEnableOrderBook(OrderBookType.kNone);        //是否开启委托簿计算功能
        cfg.setEntrySize(10);                               //委托簿输出档位数量
        cfg.setThreadNum((short)3);                         //每个档位输出的委托队列揭示
        cfg.setOrderQueueSize((short)10);                   //计算委托簿的线程数量
        cfg.setOrderBookDeliverIntervalMicrosecond(0);      //递交的最小时间间隔(微妙),默认10ms

        /*
            配置UMS信息:
            username/password 账户名/密码, 一个账户只能保持一个连接接入 (注意: 如果需要使用委托簿功能,注意账号需要有委托簿功能权限)
            ums地址配置:
                1) ums地址可以配置1-8个 建议值为2 互为主备, UmsServerCnt 为此次配置UMS地址的个数
                2) UMSItem 为UMS地址信息数据结构:
                    LocalIp 为本地地址,填0.0.0.0 或者本机ip
                    ServerIp 为ums服务端地址
                    ServerPort 为ums服务端端口
        */
        cfg.setUsername("amatest");
        cfg.setPassword("123456");

        UMSItem item1 = new UMSItem();
        item1.setLocalIp("0.0.0.0");
        item1.setServerIp("10.23.128.35");
        item1.setServerPort(8200);

        UMSItem item2 = new UMSItem();
        item2.setLocalIp("0.0.0.0");
        item2.setServerIp("10.23.128.49");
        item2.setServerPort(8200);

        cfg.setUmsServerCnt(2);
        Tools.setUMSServers(cfg.getUmsServers(), 0, item1);
        Tools.setUMSServers(cfg.getUmsServers(), 1, item2);

        /*
            业务数据回调接口(不包括 OnIndicator/OnLog等功能数据回调)的线程安全模式设置:
            true: 所有的业务数据接口为接口集线程安全
            false: 业务接口单接口为线程安全,接口集非线程安全
        */
        cfg.setIsThreadSafe(false);
        
        IAMDSpiApp spi = new IAMDSpiApp();  //初始化继承基类IAMDSpi的回放数据回调类
        /*
            初始化回调以及配置信息,此函数为异步函数, 如果通道初始化以及登陆出现问题会通过onLog / onEvent 返回初始化结果信息
        */
        final int ret = IAMDApi.init(spi, cfg);
        if(ret == ErrorCode.kSuccess) {
            log(LogLevel.kInfo, "AmaDemo", "!!!Init ama successfully!!!");
            try {
                /*TODO*/
                //初始化成功后可以发起订阅/请求代码表,可以根据需求调用和修改示例函数

                // subscribeWithDataAuth();     // 数据权限订阅示例代码
                // subscribeWithCategory();     // 品种订阅示例代码
                // getRDIData();                // RDI数据获取示例
                // getIMCExchangeRateData();    // 国际市场港股汇率数据获取示例
                // getETFCodeTable();           // etf 代码表请求代码示例
                // getCodeTable();              // 代码表请求代码示例
                // subscribeDerivedData();      // 行情衍生数据订阅示例
                // reqReplayHistory();          // 请求回放历史数据代码示例
                // Thread.sleep(3000);
                // if(spi.is_aes_logon) {
                //     subscribeOrderBook();        // 委托簿数据订阅示例
                // }

                /* 保持主线程不退出 */
                while(isRunning) {
                    Thread.sleep(2000);
                }
            } catch (InterruptedException e) {
                e.printStackTrace(); 
            }

        } else {
            log(LogLevel.kInfo, "AmaDemo", "Init ama failed");
        }

        IAMDApi.release();
        return;
    }
}
