#!/usr/bin/env python
# coding=utf-8

import sys
sys.path.append('../')
import signal
import os
import ama
import argparse
import time,datetime
import json
from IAMDSpiApp import IAMDSpiApp

is_exit_flag = False
spi = IAMDSpiApp()

def Init():
    cfg = ama.Cfg()
    '''
    通道模式设置及各个通道说明:
    cfg.channel_mode = ama.ChannelMode.kTCP   #TCP 方式计入上游行情系统
    cfg.channel_mode = ama.ChannelMode.kAMI   #AMI 组播方式接入上游行情系统
    cfg.channel_mode = ama.ChannelMode.kRDMA  #开启硬件加速RDMA通道,抓取网卡数据包数据
    cfg.channel_mode = ama.ChannelMode.kEXA   #开启硬件加速EXA通道,抓取网卡数据包数据
    cfg.channel_mode = ama.ChannelMode.kPCAP  #开启硬件加速PCAP通道,抓取网卡数据包数据
    cfg.channel_mode = ama.ChannelMode.kMDDP  #直接接入交易所网关组播数据,现在只有深圳交易所开通了此服务
    cfg.channel_mode = ama.ChannelMode.kFPGA  #FPGA通道接入数据
    cfg.channel_mode = ama.ChannelMode.kUDP   #AMD组播方式获取数据
    cfg.channel_mode = ama.ChannelMode.kTCP | ama.ChannelMode.kAMI #同时通过TCP方式和AMI组播方式接入上游,通过cfg.ha_mode 设置对应的高可用设置模式
    '''
    cfg.channel_mode = ama.ChannelMode.kTCP #TCP 方式计入上游行情系统

    cfg.tcp_compress_mode = 0               #TCP传输数据方式: 0 不压缩 1 华锐自定义压缩 2 zstd压缩(仅TCP模式有效)

    '''
        通道高可用模式设置
        1. cfg.channel_mode 为单通道时,建议设置值为kMasterSlaveA / kMasterSlaveB
        2. cfg.channel_mode 混合开启多个通道时,根据需求设置不同的值
            1) 如果需要多个通道为多活模式接入,请设置kRegularDataFilter值
            2) 如果需要多个通道互为主备接入,请设置值为kMasterSlaveA / kMasterSlaveB,kMasterSlaveA / kMasterSlaveB 差别请参看注释说明
               通道优先级从高到低依次为 kRDMA/kEXA/kMDDP/kAMI/kTCP/kPCAP
    '''
    cfg.ha_mode = ama.HighAvailableMode.kMasterSlaveA

    cfg.min_log_level = ama.LogLevel.kInfo #设置日志最小级别：Info级, AMA内部日志通过 OnLog 回调函数返回

    '''
    设置是否输出监控数据: true(是), false(否), 监控数据通过OnIndicator 回调函数返回
    监控数据格式为json, 主要监控数据包括订阅信息,数据接收数量统计
    数据量统计:包括接收数量和成功下发的数量统计,两者差值为过滤的数据量统计
    eg: "RecvSnapshot": "5926", "SuccessSnapshot": "5925",表示接收了快照数据5926个,成功下发5925个,过滤数据为 5926 - 5925 = 1 个
        过滤的数据有可能为重复数据或者非订阅数据
    '''
    cfg.is_output_mon_data = False

    '''
    设置逐笔保序开关: true(开启保序功能) , false(关闭保序功能),现阶段只对MDDP通道和委托簿本地构建生效
    主要校验逐笔成交数据和逐笔委托数据是否有丢失,如果丢失会有告警日志,缓存逐笔数据并等待keep_order_timeout_ms(单位ms)时间等待上游数据重传,
    如果超过此时间,直接下发缓存数据,默认数据已经丢失,如果之后丢失数据过来也会丢弃。
    同时由于深圳和上海交易所都是通道内序号连续,如果打开了保序开关,必须订阅全部代码的逐笔数据,否则一部分序号会被订阅过滤,导致数据超时等待以及丢失告警。
    '''
    cfg.keep_order = False
    cfg.keep_order_timeout_ms = 3000

    cfg.is_subscribe_full = False #设置默认订阅: True 代表默认全部订阅, False 代表默认全部不订阅

    '''
    委托簿千档行情参数设置(仅委托簿版本API有效,若非委托簿版本参数设置无效):
        1) 行情输出设置,包括档位数量以及每档对应的委托队列数量
        2)委托簿计算输出参数设置,包括线程数量以及递交间隔设置
    '''
    cfg.enable_order_book = ama.OrderBookType.kServerOrderBook         #是否开启委托簿计算功能
    cfg.entry_size = 10                                     #委托簿输出档位数量
    cfg.thread_num = 3                                      #每个档位输出的委托队列揭示
    cfg.order_queue_size = 10                               #计算委托簿的线程数量
    cfg.order_book_deliver_interval_microsecond = 0         #递交的最小时间间隔(微妙),默认10ms

    '''
    配置UMS信息:
    username/password 账户名/密码, 一个账户只能保持一个连接接入 (注意: 如果需要使用委托簿功能,注意账号需要有委托簿功能权限)
    ums地址配置:
        1) ums地址可以配置1-8个 建议值为2 互为主备, ums_server_cnt 为此次配置UMS地址的个数
        2) ums_servers 为UMS地址信息数据结构:
            local_ip 为本地地址,填0.0.0.0 或者本机ip
            server_ip 为ums服务端地址
            server_port 为ums服务端端口
    '''
    cfg.username =  "amatest"
    cfg.password = "amatest"
    cfg.ums_server_cnt = 2
    item = ama.UMSItem()
    item.local_ip = "0.0.0.0"
    item.server_ip = "10.23.128.35"
    item.server_port = 8200
    ama.Tools.SetUMSServers(cfg.ums_servers, 0, item)
    item1 = ama.UMSItem()
    item1.local_ip = "0.0.0.0"
    item1.server_ip = "10.23.128.49"
    item1.server_port = 8200
    ama.Tools.SetUMSServers(cfg.ums_servers, 1, item1)

    '''
    业务数据回调接口(不包括 OnIndicator/OnLog等功能数据回调)的线程安全模式设置:
        true: 所有的业务数据接口为接口集线程安全
        false: 业务接口单接口为线程安全,接口集非线程安全
    '''
    cfg.is_thread_safe = False

    '''
    初始化回调以及配置信息,此函数为异步函数, 
    如果通道初始化以及登陆出现问题会通过onLog / onEvent 返回初始化结果信息
    '''
    return ama.IAMDApi.Init(spi, cfg)

def Release():
    return ama.IAMDApi.Release()

#数据权限订阅示例代码
def SubscribeWithDataAuth():
    '''
    按照权限订阅信息设置:
        1. 订阅信息分三个维度:
            market: 设置订阅的市场
            flag: 设置订阅的权限数据类型
            security_code: 设置订阅的代码
        2. 订阅操作有三种:
            kSet 设置订阅, 新的订阅会覆盖之前的所有订阅信息
            kAdd 增加订阅, 在前一个基础上增加订阅信息
            kDel 删除订阅, 在前一个基础上删除订阅信息
            kCancelAll 取消所有订阅信息
    '''

    # 创建2个存储订阅代码信息的subItems数组空间(数组空间在没有初始化的情况下,里面的值是不确定的,订阅上送时可能会导致订阅与预期不符)
    subItems = ama.Tools.CreateSubscribeItem(2)

    # 订阅信息1：订阅深交所全部证券的逐笔委托和逐笔成交
    item1 = ama.SubscribeItem()
    item1.market = ama.MarketType.kSZSE
    item1.flag = ama.SubscribeDataType.kTickOrder | ama.SubscribeDataType.kTickExecution
    item1.security_code = ""
    ama.Tools.SetSubscribeItem(subItems, 0, item1)      # 设置subItems数组的第0位内存空间

    # 订阅信息2：订阅上交所600000证券的快照
    item2 = ama.SubscribeItem()
    item2.market = ama.MarketType.kSSE
    item2.flag = ama.SubscribeDataType.kSnapshot
    item2.security_code = "600000"
    ama.Tools.SetSubscribeItem(subItems, 1, item2)      # 设置subItems数组的第1位内存空间
   
    '''
    以kSet发起订阅,设置两条订阅信息(此前所有已设置好的订阅信息都将会被覆盖)
    因为发起订阅的数量为2,因此会上送subItems[0]和subItems[1]的订阅信息
    订阅结果：
        深交所全部证券的逐笔委托和逐笔成交 + 上交所600000证券的快照
    '''
    ret = ama.IAMDApi.SubscribeData(ama.SubscribeType.kSet, subItems, 2)
    if(ret != ama.ErrorCode.kSuccess):
        return ret

    # kAdd、kDel、kCancelAll订阅操作示例,可根据需求调用
    if(False):
        # 订阅信息3：订阅上交所600001证券的快照
        item3 = ama.SubscribeItem()
        item3.market = ama.MarketType.kSSE
        item3.flag = ama.SubscribeDataType.kSnapshot
        item3.security_code = "600001"
        ama.Tools.SetSubscribeItem(subItems, 0, item3)      # 设置subItems数组的第0位内存空间
    
        '''
        以kAdd方式发起订阅,在已有基础上增加一条订阅信息
        因为发起订阅的数量为1,因此最终只会上送subItems[0]的订阅信息
        订阅结果：
            深交所全部证券的逐笔委托和逐笔成交 + 上交所600000证券的快照 + 上交所600001证券的快照
        '''
        ret = ama.IAMDApi.SubscribeData(ama.SubscribeType.kAdd, subItems, 1)
        if(ret != ama.ErrorCode.kSuccess):
            return ret

        '''
        以kDel发起订阅,在已有基础上删除一条订阅信息
        因为发起订阅的数量为1,因此最终只会上送subItems[0]的订阅信息
        订阅结果：
                深交所全部证券的逐笔委托和逐笔成交 + 上交所600000证券的快照
        '''
        ret = ama.IAMDApi.SubscribeData(ama.SubscribeType.kDel, subItems, 1)
        if(ret != ama.ErrorCode.kSuccess):
            return ret

        '''
        以kCancelAll发起订阅,取消所有订阅信息
        订阅结果：
            无
        '''
        ret = ama.IAMDApi.SubscribeData(ama.SubscribeType.kCancelAll, subItems, 2)
        if(ret != ama.ErrorCode.kSuccess):
            return ret

    # 订阅调用完后释放subItems空间
    ama.Tools.DestroySubscribeItem(subItems)
    return 0

#品种订阅示例代码
def SubscribeWithCategory():
    '''
    按品种类型订阅信息设置:
        1. 订阅信息分三个维度:
            market: 设置订阅的市场
            data_type: 设置订阅的证券数据类型
            category_type: 设置订阅的品种类型
            security_code: 设置订阅的代码
        2. 订阅操作有三种:
            kSet 设置订阅, 新的订阅会覆盖之前的所有订阅信息
            kAdd 增加订阅, 在前一个基础上增加订阅信息
            kDel 删除订阅, 在前一个基础上删除订阅信息
            kCancelAll 取消所有订阅信息
    '''

    # 创建2个存储订阅代码信息的subItems数组空间(数组空间在没有初始化的情况下,里面的值是不确定的,订阅上送时可能会导致订阅与预期不符)
    subItems = ama.Tools.CreateSubscribeCategoryItem(2)
    
    # 订阅信息1：深交所全部证券代码的股票快照和逐笔成交
    item1 = ama.SubscribeCategoryItem()
    item1.market = ama.MarketType.kSZSE
    item1.data_type = ama.SubscribeSecuDataType.kSnapshot | ama.SubscribeSecuDataType.kTickExecution
    item1.category_type = ama.SubscribeCategoryType.kStock
    item1.security_code = "" 
    ama.Tools.SetSubscribeCategoryItem(subItems, 0, item1)  # 设置subItems数组的第0位内存空间

    # 订阅信息2：上交所全部证券代码的基金快照
    item2 = ama.SubscribeCategoryItem()
    item2.market = ama.MarketType.kSSE
    item2.data_type = ama.SubscribeSecuDataType.kSnapshot
    item2.category_type = ama.SubscribeCategoryType.kFund
    item2.security_code = "" 
    ama.Tools.SetSubscribeCategoryItem(subItems, 1, item2)  # 设置subItems数组的第1位内存空间

    '''
    以kSet发起订阅,设置两条订阅信息(此前所有已设置好的订阅信息都将会被覆盖)
    因为发起订阅的数量为2,因此会上送subItems[0]和subItems[1]的订阅信息
    订阅结果：
        深交所全部证券代码的股票快照和逐笔成交 + 上交所全部证券代码的基金快照
    '''
    ret = ama.IAMDApi.SubscribeData(ama.SubscribeType.kSet, subItems, 2)
    if(ret != ama.ErrorCode.kSuccess):
        return ret
  
    # kAdd、kDel、kCancelAll订阅操作示例,可根据需求调用
    if(False):
       # 订阅信息3：上交所全部证券代码的债券快照
        item1 = ama.SubscribeCategoryItem()
        item1.market = ama.MarketType.kSSE
        item1.data_type = ama.SubscribeSecuDataType.kSnapshot
        item1.category_type = ama.SubscribeCategoryType.kBond
        item1.security_code = "" 
        ama.Tools.SetSubscribeCategoryItem(subItems, 0, item1)  # 设置subItems数组的第0位内存空间 

        '''
        以kAdd方式发起订阅,在已有基础上增加一条订阅信息
        因为发起订阅的数量为1,因此最终只会上送subItems[0]的订阅信息
        订阅结果：
            深交所全部证券代码的股票快照和逐笔成交 + 上交所全部证券代码的基金快照 + 上交所全部证券代码的债券快照
        '''
        ret = ama.IAMDApi.SubscribeData(ama.SubscribeType.kAdd, subItems, 1)
        if(ret != ama.ErrorCode.kSuccess):
            return ret

        '''
        以kDel发起订阅,在已有基础上删除一条订阅信息
        因为发起订阅的数量为1,因此最终只会上送subItems[0]的订阅信息
        订阅结果：
            深交所全部证券代码的股票快照和逐笔成交 + 上交所全部证券代码的基金快照
        '''
        ret = ama.IAMDApi.SubscribeData(ama.SubscribeType.kDel, subItems, 1)
        if(ret != ama.ErrorCode.kSuccess):
            return ret

        '''
        以kCancelAll发起订阅,取消所有订阅信息
        订阅结果：
            无
        '''
        ret = ama.IAMDApi.SubscribeData(ama.SubscribeType.kCancelAll, subItems, 2)
        if(ret != ama.ErrorCode.kSuccess):
            return ret
    
    # 订阅调用完后释放subItems空间
    ama.Tools.DestroySubscribeCategoryItem(subItems)
    return 0

#委托簿数据订阅示例,此接口后续逐步弃用, 用subscribeDerivedData接口替代
def SubscribeOrderBook():
    # 创建2个存储订阅代码信息的orderItems数组空间(数组空间在没有初始化的情况下,里面的值是不确定的,订阅上送时可能会导致订阅与预期不符)
    orderItems = ama.Tools.CreateSubscribeOrderBookItem(2)
    
    # 订阅信息1(订阅上交所"600000"证券代码的委托簿数据)
    item1 = ama.SubscribeOrderBookItem()
    item1.market = ama.MarketType.kSSE
    item1.flag = ama.SubscribeOrderBookDataType.kOrderBook
    item1.security_code = "600000"
    ama.Tools.SetSubscribeOrderBookItem(orderItems, 0, item1)   # 初始化orderItems数组的第0位内存空间

    # 订阅信息2(订阅深交所"000001"证券的委托簿数据 & 委托簿快照数据 )
    item2 = ama.SubscribeOrderBookItem()
    item2.market = ama.MarketType.kSZSE
    item2.flag = ama.SubscribeOrderBookDataType.kNone
    item2.security_code = "000001"
    ama.Tools.SetSubscribeOrderBookItem(orderItems, 1, item2)   # 初始化orderItems数组的第1位内存空间

    '''
    以kSet发起订阅,设置两条订阅信息(此前所有已设置好的订阅信息都将会被覆盖)
    因为发起订阅的数量为2,因此会上送orderItems[0]和orderItems[1]的订阅信息
    订阅结果：
        上交所"600000"证券代码的委托簿数据 + 订阅深交所"000001"证券的委托簿数据 & 委托簿快照数据
    '''
    ret = ama.IAMDApi.SubscribeOrderBookData(ama.SubscribeType.kSet, orderItems, 2)
    if(ret != ama.ErrorCode.kSuccess):
        return ret

    # kAdd、kDel、kCancelAll订阅操作示例,可根据需求调用
    if(False):
        # 订阅信息3(订阅上交所"600001"证券代码的委托簿数据)
        item3 = ama.SubscribeOrderBookItem()
        item3.market = ama.MarketType.kSSE
        item3.flag = ama.SubscribeOrderBookDataType.kOrderBook
        item3.security_code = "600001"
        ama.Tools.SetSubscribeOrderBookItem(orderItems, 0, item3)   # 设置orderItems数组的第0位内存空间
    
        '''
        以kAdd方式发起订阅,在已有基础上增加一条订阅信息
        因为发起订阅的数量为1,因此最终只会上送orderItems[0]的订阅信息
        订阅结果：
            上交所"600000"证券代码的委托簿数据 + 上交所"600001"证券代码的委托簿数据 + 订阅深交所"000001"证券的委托簿数据 & 委托簿快照数据
        '''
        ret = ama.IAMDApi.SubscribeOrderBookData(ama.SubscribeType.kAdd, orderItems, 1)
        if(ret != ama.ErrorCode.kSuccess):
            return ret

        '''
        以kDel方式发起订阅,在已有基础上增加一条订阅信息
        因为发起订阅的数量为1,因此最终只会上送orderItems[0]的订阅信息
        订阅结果：
            上交所"600000"证券代码的委托簿数据 + 订阅深交所"000001"证券的委托簿数据 & 委托簿快照数据
        '''
        ret = ama.IAMDApi.SubscribeOrderBookData(ama.SubscribeType.kDel, orderItems, 1)
        if(ret != ama.ErrorCode.kSuccess):
            return ret

        '''
        以kCancelAll发起订阅,取消所有订阅信息
        订阅结果：
            无
        '''
        ret = ama.IAMDApi.SubscribeOrderBookData(ama.SubscribeType.kCancelAll, orderItems, 2)
        if(ret != ama.ErrorCode.kSuccess):
            return ret

    # 订阅调用完后释放orderItems空间
    ama.Tools.DestroySubscribeOrderBookItem(orderItems)
    return 0

#行情衍生数据订阅示例
def SubscribeDerivedData():
    # 创建2个存储订阅代码信息的derivedItems数组空间(数组空间在没有初始化的情况下,里面的值是不确定的,订阅上送时可能会导致订阅与预期不符)
    derivedItems = ama.Tools.CreateSubscribeDerivedDataItem(2)

    # 订阅信息1(订阅上交所"510020"证券代码)
    derived_item1 = ama.SubscribeDerivedDataItem()
    derived_item1.market = ama.MarketType.kSSE
    derived_item1.security_code = "510020"
    ama.Tools.SetSubscribeDerivedDataItem(derivedItems, 0, derived_item1)   # 初始化derivedItems数组的第0位内存空间

    # 订阅信息2(订阅深交所"159930"证券代码)
    derived_item2 = ama.SubscribeDerivedDataItem()
    derived_item2.market = ama.MarketType.kSZSE
    derived_item2.security_code = "159930"
    ama.Tools.SetSubscribeDerivedDataItem(derivedItems, 1, derived_item2)   # 初始化derivedItems数组的第1位内存空间

    '''
    以kSet发起订阅,设置两条订阅信息(此前所有已设置好的订阅信息都将会被覆盖),订阅数据类型见对应开发指南
    因为发起订阅的数量为2,因此会上送derivedItems[0]和derivedItems[1]的订阅信息
    订阅结果：
        上交所"510020"证券代码的IOPV快照数据 + 深交所"159930"证券代码的IOPV快照数据
    '''
    ret = ama.IAMDApi.SubscribeDerivedData(ama.SubscribeType.kSet, ama.SubscribeDerivedDataType.kIOPVSnapshot, derivedItems, 2)
    if(ret != ama.ErrorCode.kSuccess):
        return ret

    # kAdd、kDel、kCancelAll订阅操作示例,可根据需求调用
    if(False):
        '''
        以kAdd发起订阅,在已有基础上增加两条订阅信息,订阅数据类型见对应开发指南
        因为发起订阅的数量为2,因此会上送derivedItems[0]和derivedItems[1]的订阅信息
        订阅结果：
            上交所"510020"证券代码的IOPV快照数据 & 委托簿快照数据 + 深交所"159930"证券代码的IOPV快照数据 & 委托簿快照数据
        '''
        ret = ama.IAMDApi.SubscribeDerivedData(ama.SubscribeType.kAdd, ama.SubscribeDerivedDataType.kOrderBookSnapshot, derivedItems, 2)
        if(ret != ama.ErrorCode.kSuccess):
            return ret

        '''
        以kDel发起订阅,在已有基础上删除一条订阅信息,订阅数据类型见对应开发指南
        因为发起订阅的数量为1,因此会上送derivedItems[0]的订阅信息
        订阅结果：
            上交所"510020"证券代码的IOPV快照数据 + 深交所"159930"证券代码的IOPV快照数据 & 委托簿快照数据
        '''
        ret = ama.IAMDApi.SubscribeDerivedData(ama.SubscribeType.kDel, ama.SubscribeDerivedDataType.kOrderBookSnapshot, derivedItems, 2)
        if(ret != ama.ErrorCode.kSuccess):
            return ret

        '''
        以kCancelAll发起订阅,取消所有订阅信息
        订阅结果：
            无
        '''
        ret = ama.IAMDApi.SubscribeDerivedData(ama.SubscribeType.kCancelAll, ama.SubscribeDerivedDataType.kOrderBookSnapshot, derivedItems, 2)
        if(ret != ama.ErrorCode.kSuccess):
            return ret
    
    ama.Tools.DestroySubscribeDerivedDataItem(derivedItems)
    return 0

#代码表获取示例函数
def GetCodeList():
    # 预先分配2条查询信息的items数组空间(数组空间在没有初始化的情况下,里面的值是不确定的,查询信息上送时可能会与预期不符)
    items = ama.Tools.CreateSubCodeTableItem(2)

    # 查询信息1(查询深交所“000001”的代码表数据),查询的详细规则见配套开发指南。
    item1 = ama.SubCodeTableItem()      
    item1.market = ama.MarketType.kSZSE                      
    item1.security_code = "000001"   
    ama.Tools.SetSubCodeTableItem(items, 0, item1)  # 初始化items数组的第0位内存空间

    # 查询信息2(查询上交所“600000”的代码表数据),查询的详细规则见配套开发指南。
    item2 = ama.SubCodeTableItem() 
    item2.market = ama.MarketType.kSSE                      
    item2.security_code = "600000"
    ama.Tools.SetSubCodeTableItem(items, 1, item2) # 初始化items数组的第1位内存空间

    recordlist = ama.CodeTableRecordList()
    result = ama.IAMDApi.GetCodeTableList(recordlist, items, 2) # 发起查询,上送items[0]和items[1]的查询信息；查询后的数据通过recordlist返回
    if(result):
        listNums = recordlist.list_nums
        records = recordlist.records
        for i in range(listNums): 
            # 获取一条代码表数据record
            record = ama.Tools.GetDataByIndex(records, i)

            '''获取到代码表信息后,可以根据需求对代码表信息进行处理 '''
            print(ama.Tools.Serialize(record))
    
        # records使用完后需要手动释放内存
        if (listNums > 0):
            ama.Tools.FreeMemory(records)
            return listNums

    # 查询调用完后释放items空间
    ama.Tools.DestroySubCodeTableItem(items)
    return 0

#ETF代码表获取示例函数
def GetETFCodeList():
    # // 预先分配2条查询信息的etfItems数组空间(数组空间在没有初始化的情况下,里面的值是不确定的,查询信息上送时可能会与预期不符)
    etf_items = ama.Tools.CreateETFItem(2)

    # 查询信息1(查询深交所全部代码的ETF代码表数据),查询的详细规则见配套开发指南。
    item1 = ama.ETFItem()
    item1.market = ama.MarketType.kSZSE                      
    item1.security_code = ""   
    ama.Tools.SetETFItem(etf_items, 0, item1)       # 初始化etfItems数组的第0位内存空间

    # 查询信息2(查询上交所全部代码的ETF代码表数据),查询的详细规则见配套开发指南。
    item2 = ama.ETFItem()
    item2.market = ama.MarketType.kSSE                      
    item2.security_code = ""
    ama.Tools.SetETFItem(etf_items, 1, item2)       # 初始化etfItems数组的第1位内存空间

    #获取etf代码表信息
    recordlist = ama.ETFCodeTableRecordList()
    result = ama.IAMDApi.GetETFCodeTableList(recordlist ,etf_items, 2)    # 发起查询,上送etfItems[0]和etfItems[1]的查询信息；查询后的数据通过recordlist返回
    if(result):
        listNums = recordlist.etf_list_nums
        records = recordlist.etf_records
        for i in range(listNums): 
            # 获取一条ETF代码表数据record
            record = ama.Tools.GetDataByIndex(records, i)

            '''获取到代码表信息后,可以根据需求对代码表信息进行处理 '''
            print(ama.Tools.Serialize(record))
    
        # records使用完后需要手动释放内存
        if (listNums > 0):
            ama.Tools.FreeMemory(records)
            return listNums

    # 查询调用完后释放items空间
    ama.Tools.DestroyETFItem(etf_items)
    return 0

#国际市场港股汇率数据获取示例函数
def GetIMCExchangeRateData():
    list = ama.IMCExchangeRateList()

    ret = ama.IAMDApi.GetIMCExchangeRate(list)
    if(ret):
        list_num = list.imc_list_nums
        rate_datas = list.imc_rate_data
        for i in range(list_num):
            # 获取一条IMC数据record
            record = ama.Tools.GetDataByIndex(rate_datas, i)

            '''获取到IMC数据信息后,可以根据需求对IMC数据信息进行处理 '''
            print(ama.Tools.Serialize(record))

        # 释放港股汇率数据内存
        if(list_num > 0):
            ama.Tools.FreeMemory(list.imc_rate_data)
            return list_num

    return 0

#RDI数据获取示例函数
def GetRDICodeList():
    # 预先分配2条查询信息的rdiItems数组空间(数组空间在没有初始化的情况下,里面的值是不确定的,查询信息上送时可能会与预期不符)
    rdi_items = ama.Tools.CreateRDIQueryItem(2)

    # 查询信息1(查询代码"010011"的RDI数据,代码为空时("")表示订阅所有代码)
    item1 = ama.RDIQueryItem()
    item1.security_code = "010011"   
    ama.Tools.SetRDIQueryItem(rdi_items, 0, item1)      # 设置rdiItems数组的第0位内存空间

    #设置查询010214这只代码,如果需要查询全部代码,security_code设置为空("")即可
    item2 = ama.RDIQueryItem()
    item2.security_code = "010214"   
    ama.Tools.SetRDIQueryItem(rdi_items, 1, item2)      # 设置rdiItems数组的第1位内存空间

    #获取RDI信息
    '''
    获取债券信息(银行间) BondInfoInterbankList/GetBondInfoInterbank
    获取资产支持证券信息(ABS) ABSInfoList/GetABSInfo
    获取资产支持证券历史信息(ABS历史) ABSHistoryInfoList/GetABSHistoryInfo
    获取资产支持证券信用评级数据 ABSCreditRatingsList/GetABSCreditRatings
    获取预发行债券信息数据 PreIssuedBondInfoList/GetPreIssuedBondInfo
    获取上市前债券信息(银行间)数据 PreIPOBondInfoList/GetPreIPOBondInfo
    获取可交易债券信息数据 XBondTradeBondInfoList/GetXBondTradeBondInfo
    获取质押券折算率(匿名点击)信息 PledgedConvertRateACInfoList/GetPledgedConvertRateACInfo
    获取X-Repo 分层报价群组信息数据 XRepoHierQuoteGroupInfoList/GetXRepoHierQuoteGroupInfo(没有代码信息,接口无item参数)
    获取X-Repo 合约信息数据 XRepoContractInfoList/GetXRepoContractInfo
    获取利率互换(固浮)信息数据 SwapFixedFloatInfoList/GetSwapFixedFloatInfo
    获取利率互换(固浮)期差基差合约信息数据 SwapFixedFloatBasisContractInfoList/GetSwapFixedFloatBasisContractInfo
    '''
    rdi_list = ama.BondInfoInterbankList()
    result = ama.IAMDApi.GetBondInfoInterbank(rdi_list ,rdi_items, 2)       # 获取RDI数据
    if(result):
        listNums = rdi_list.data_cnt
        records = rdi_list.data
        for i in range(listNums): 
            # 获取一条RDI数据record
            record = ama.Tools.GetDataByIndex(records, i)

            '''获取到RDI数据后,可以根据需求对数据进行处理'''
            print(ama.Tools.Serialize(record))

        if(listNums > 0):
            ama.Tools.FreeMemory(records)
            return listNums
   
    # 订阅调用完后释放rdiItems空间
    ama.Tools.DestroyRDIQueryItem(rdi_items)
    return 0

def CtrlC(signum, frame):
    global is_exit_flag
    is_exit_flag = True

if(__name__ == "__main__"):
    signal.signal(signal.SIGINT, CtrlC)
    signal.signal(signal.SIGTERM, CtrlC)

    Init()
    ''' TODO 按照实际需求调用不同的接口函数 '''
    # SubscribeWithDataAuth()     # 数据权限订阅示例
    # SubscribeWithCategory()     # 品种订阅示例
    # SubscribeDerivedData()      # 行情衍生数据订阅示例
    # GetCodeList()               # 代码表获取示例函数
    # GetETFCodeList()            # ETF代码表获取示例函数
    # GetRDICodeList()            # RDI数据获取示例函数
    # GetIMCExchangeRateData()    # 国际市场港股汇率数据获取示例函数

    # time.sleep(3)
    # if(spi.is_aes_logon):
    #     SubscribeOrderBook()    # 委托簿数据订阅示例
    while(is_exit_flag == False):
        try:
            input()
        except:
            is_exit_flag = True
    Release()


